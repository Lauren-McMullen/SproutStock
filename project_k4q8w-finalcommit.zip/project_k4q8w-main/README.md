# CPSC 210 Term Project - SproutStock

## Flower Shop Inventory and Recipe Manager 

Any business owner knows that keeping track of store inventory is a key aspect of successful operation, budgeting, 
and customer relationship management. Prior to starting my computer science degree at The University of British
Columbia, I worked as a florist for 4 years. During this time, I encountered pain points where inefficient 
inventory management meant that we ran out of flowers before orders were fulfilled (have you ever tried explaining to an
angry customer why you are sold out of roses on Valentine's Day?). These experiences have motivated me to use
this personal project to explore how I can use programming to create a solution to a relevant business problem.

This application would be of use to business owners and managers of small- and medium-sized flower shops and their 
teams.The application, which I have called SproutStock, will allow teams to input and track their flower stock.
I propose that this application would have the main features of adding flowers to the inventory when shipments come in,
creating custom recipes (floral designs are often called 'recipes' in the industry) to efficiently track flower 
usage, removing flowers from the inventory once orders are fulfilled, and calculating the appropriate cost of recipes 
based on weekly flower market prices. For more details about how users will interact with the application, please 
read the user stories below.

**User Stories (Console App):**
- As a user, I want to be able to create flower types with a name, cost, and amount in stock
- As a user, I want to be able to update flower costs based on the current market price
- As a user, I want to be able to add counts of flowers from incoming shipments to my store inventory 
- As a user, I want to be able to remove flowers by the stem as I sell them
- As a user, I want to be able to view the counts, price and names of plants in my inventory
- As a user, I want to be able to create and save a recipe that uses an arbitrary amount of flowers
  - I want this recipe to have a name, price, and list of flowers needed to make it
- As a user, I want to be able to make a new order with a list of recipes from my shop.
- As a user, I want to be able to remove flowers from my inventory based on an order I fulfilled
- As a user, I want to be able to view a list of recipes that use a flower of type X 
- As a user, I want to be able to be promoted and able to save the state of my inventory (including plants, recipes, 
  and orders) when I quit the application. 
- As a user, I want to be able to load into my saved flower shop inventory state when I open the application.

## Instructions for Grader (GUI Application)

- You can add multiple Xs (Plants) to a Y (FlowerShop) by clicking into the "Inventory" tab and clicking 
"And a new plant". Enter a String name, Double price, and Integer Stem count and click "Add Plant" to confirm. 
The plant will be added to the drop box of all available plants. 

- You can generate the first required action related to the user story "adding multiple Xs to a Y" from within the 
  same inventory tab:
  - Use the dropdown menu to select any plant, and then click the **"add stems to stock"** button. 
  - A dialog box  will prompt you to enter an amount of stems to add, then click "Add stems" to confirm. 
  - The plant summary will update to reflect your change. 

- You can generate the second required action related to the user story "adding multiple Xs to a Y" from within the
  same inventory tab:
    - Use the dropdown menu to select any plant, and then click the **"delete plant from inventory"** button.
    - A popup will prompt you to confirm that you want to delete that plant, click "yes" to confirm.
    - The plant will be removed from the available plant options in the dropdown. 

- You can locate my visual component when you start the application. It will appear as a logo for the app
  ("Sprout stock") surrounded by a frame and floral graphics before the rest of the application appears. 

- You can save the state of my application by navigating to the "Home" tab:
  - click "Save"
  - A text string will update on the home tab, notifying you of the last successful save time
  - (Note that you can also save by clicking "quit" and selecting "yes" when the popup asks you if you want to
    save before you quit)

- You can reload the state of my application by navigating to the "Home" tab:
  - click "load"
  - A text string will notify you that the load was successful
  - You can check state of the Plant and Recipe tab display information to confirm that the load was successful

## Phase 4: Task 2
- Event 1 (Adding Stems): "Added " + newStock + " new stems of: " + name
- Event 2 (Selling Stems): "Sold " + stemNum + " stems of: " + name)
- Event 3 (Removing Plants): "Removed plant from the flower shop: " + plant.getName()
- Event 4 (Changing Stem Price): "Changed the price of: " + name + "to " + price
- Event 5 (Load FlowerShop): "Saved the flower shop"
- Event 6 (Save FlowerShop): "Loaded the flower shop"

## Phase 4: Task 3
Completing my first object-oriented program as my CPSC 210 project was challenging and rewarding, and one of the 
best parts of the project was learning something new in lecture and immediately thinking about how I could apply the 
concept to my own project to make it cleaner, more robust, less cluttered, etc. Of course, there is not enough time over 
one semester to perfect a project (especially for a beginner!), but given enough time, I would have liked to implement 
some of the following changes.

One of the first major refactors that I would do would be including **exception classes** to reduce the need for 
REQUIRES
clauses in my model. This would be especially helpful to ensure that users are inputting the correct input type, 
and this would have reduced the code that I used in my console menu classes to protect against invalid input quite a 
bit. Another meaningful change that I would have liked to implement is including a proper **observer pattern** in my 
UI. I was able to replicate the effect of an sort of pseudo-observer pattern by updating my tabs during key events, 
but I appreciate
how much more readable and in line with good design standards it would have been to implement the design using a 
stricter observer pattern. 

Finally, when creating my UML diagram, I noticed that I had quite a few classes storing their own FlowerShop field (the 
console menu package was particularly troublesome for this).
This made the diagram (and program structure) more complicated than it needed to be, and increased the coupling in my 
program. If I were to refactor this, I would probably give the abstract class UserMenu one copy of the App's 
flowershop so that each menu would simply inherit the field 
from the parent class. Interestingly, I can see some improvement in my program designing skills as I progressed through 
this project--by the time I created Tab and Tab's subclasses, I did just that; I gave the superclass the flowershop 
field and had each subclass access it through the superclass. 



