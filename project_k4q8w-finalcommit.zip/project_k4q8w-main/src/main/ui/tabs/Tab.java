package ui.tabs;

import model.FlowerShop;
import ui.FlowerShopAppUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


// Credits: The structure for this GUI was modeled after: https://github.students.cs.ubc.ca/CPSC210/AlarmSystem
// In all UI classes, extensive use was made of Oracle's Swing library documentation:
// https://docs.oracle.com/javase/8/docs/api/javax/swing/package-summary.html

//Abstract class the describes a tab in the SproutStock GUI
public abstract class Tab extends JPanel {

    public static final Color BACKGROUND_COLOR = new Color(156, 175, 136);
    protected FlowerShopAppUI controller;
    protected static FlowerShop flowerShop;
    protected final PopupFactory factory;

    //REQUIRES: FlowerShop controller that holds this tab
    //EFFECTS: Creates a new tab with the controller, flowerShop, and a Popup factory instance.
    public Tab(FlowerShopAppUI controller) {
        this.controller = controller;
        factory = PopupFactory.getSharedInstance();
        flowerShop = controller.getFlowerShop();
    }

    //EFFECTS: creates and returns a JPanel with the button included
    public JPanel formatRow(JComponent c) {
        JPanel p = new JPanel();
        p.setLayout(new FlowLayout(FlowLayout.CENTER));
        p.setBackground(BACKGROUND_COLOR);
        p.add(c);
        return p;
    }

    //EFFECTS: returns a formatted JDialog box that accepts user input.
    public JDialog formatDialogInputBox(String mainLabel, String promptLabel, JButton confirmButton, JTextField input) {
        JDialog newDialog = new JDialog(controller, mainLabel);
        newDialog.setLayout(new GridLayout(2,1));
        newDialog.setSize(450, 150);
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(1, 2));
        JLabel prompt = new JLabel(promptLabel);

        inputPanel.add(prompt);
        inputPanel.add(input);
        newDialog.add(inputPanel);
        newDialog.add(confirmButton);

        return newDialog;
    }

    //EFFECTS: formats a confirmation popup
    public Popup formatPopup(String message) {

        JPanel window = new JPanel(new GridLayout(2,1));
        window.setBackground(Color.WHITE);
        JButton yes = new JButton("Yes");
        JButton no = new JButton("No");
        JLabel savePrompt = new JLabel("    " + message + "    ");

        JPanel buttonRow = formatRow(yes);
        buttonRow.add(no);
        buttonRow.setBackground(Color.WHITE);

        window.add(savePrompt);
        window.add(buttonRow);

        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                popupYesConfirmation();
            }
        });

        no.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                popupNoConfirmation();
            }
        });

        return factory.getPopup(this, window, 500, 250);

    }

    //EFFECTS: defines the action for the yes action on the confirmation popup
    public abstract void popupYesConfirmation();

    //EFFECTS: defines the action for the no action on the confirmation popup
    public abstract void popupNoConfirmation();

}











