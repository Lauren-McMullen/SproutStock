package ui.tabs;


// Credits: The structure for this GUI was modeled after: https://github.students.cs.ubc.ca/CPSC210/AlarmSystem

// In all UI classes, extensive use was made of Oracle's Swing library documentation:
// https://docs.oracle.com/javase/8/docs/api/javax/swing/package-summary.html

// Information about making aesthetic changes to JLabel fonts were found at:
//https://stackoverflow.com/questions/2715118/how-to-change-the-size-of-the-font-of-a-jlabel-to-take-the-maximum-size
// EVENT PRINTING: https://github.students.cs.ubc.ca/CPSC210/AlarmSystem.git

// Manages the home tab in the Sprout Stock GUI, including the logo image and save, load, and quit functionalities.

import model.EventLog;
import model.Event;
import persistence.JsonReader;
import persistence.JsonWriter;
import ui.FlowerShopAppUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;

public class HomeTab extends Tab {

    private static final String JSON_STORE = "./data/myGUIFlowerShop.json";
    private static final String WELCOME_TEXT = "Welcome to Sprout Stock!";

    private final JsonWriter jsonWriter;
    private final JsonReader jsonReader;
    private JLabel homeText;
    private JLabel saveLoadText;
    private Popup quitPopup;

    //EFFECTS: constructs a home tab with save, load and quit buttons and a greeting.
    public HomeTab(FlowerShopAppUI controller) {
        super(controller);
        jsonReader = new JsonReader(JSON_STORE);
        jsonWriter = new JsonWriter(JSON_STORE);
        setLayout(new GridLayout(5,1));

        placeWelcomeText();
        placeSaveLoadButtons();
        placeSaveLoadText();
        placeQuitButton();
    }

    //MODIFIES: this
    //EFFECTS: Sets the home tab text at the top of the page
    private void placeWelcomeText() {
        homeText = new JLabel(WELCOME_TEXT, JLabel.CENTER);
        homeText.setSize(WIDTH, HEIGHT / 3);
        homeText.setFont(new Font("Serif", Font.PLAIN, 30));
        this.add(homeText);
    }

    //MODIFIES: this
    //EFFECTS: Initializes the last save time text to a blank string and places it
    //         in the home tab
    private void placeSaveLoadText() {
        saveLoadText = new JLabel("", JLabel.CENTER);
        saveLoadText.setSize(WIDTH, HEIGHT / 3);
        saveLoadText.setFont(new Font("Serif", Font.PLAIN, 15));
        this.add(saveLoadText);
    }

    //MODIFIES: this
    //EFFECTS: Creates the save and load buttons that perform their respective actions
    private void placeSaveLoadButtons() {
        JButton saveButton = new JButton("Save");
        JButton loadButton = new JButton("Load");
        JPanel buttonRow = formatRow(saveButton);
        buttonRow.add(loadButton);
        buttonRow.setSize(WIDTH, HEIGHT / 6);
        buttonRow.setBackground(BACKGROUND_COLOR);

        saveLoadActions(saveButton, loadButton);

        this.add(buttonRow);
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: adds action listeners for the save and load buttons
    private void saveLoadActions(JButton save, JButton load) {
        //EFFECTS: saves the controller's current flowerShop state to JSON_STORE
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonPressed = e.getActionCommand();
                if (buttonPressed.equals("Save")) {
                    saveFlowerShop();
                }
            }
        });

        //EFFECTS: loads the flowerShop from controller's JSON_STORE
        load.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonPressed = e.getActionCommand();
                if (buttonPressed.equals("Load")) {
                    loadFlowerShop();
                }
            }
        });

    }

    //MODIFIES: this
    //EFFECTS: Saves the current flowerShop state to the controller's JSON_STORE
    public void saveFlowerShop() {
        try {
            jsonWriter.open();
            jsonWriter.write(flowerShop);
            jsonWriter.close();
            saveLoadText.setText("Last Save: " + Calendar.getInstance().getTime());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: loads the flowerShop from controller's JSON_STORE
    public void loadFlowerShop() {
        try {
            flowerShop = jsonReader.read();
            controller.setFlowerShop(flowerShop);
            updateTabs();
            saveLoadText.setText("Data Successfully loaded!");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //MODIFIES: controller
    //EFFECTS: Updates each of the inventory, order, and recipe tabs controlled by the contoller
    public void updateTabs() {
        InventoryTab inventoryTab = (InventoryTab) controller.getInventoryTab();
        inventoryTab.updateTab();

        OrdersTab ordersTab = (OrdersTab) controller.getOrderTab();
        ordersTab.updateTab();

        RecipesTab recipesTab = (RecipesTab) controller.getRecipeTab();
        recipesTab.updateTab();
    }

    //MODIFIES: this
    //EFFECTS: Creates and places a quit button that offers the option to save before quitting.
    private void placeQuitButton() {
        JButton quitButton = new JButton("Quit");

        JPanel buttonRow = formatRow(quitButton);
        buttonRow.setSize(WIDTH, HEIGHT / 6);
        buttonRow.setBackground(BACKGROUND_COLOR);


        //EFFECTS: Prompts user to save, then terminates the program
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                quitPopup = formatPopup("Would you like to save before you quit?");
                quitPopup.show();
            }
        });

        this.add(buttonRow);
    }

    //MODIFIES: flowerShop
    //EFFECTS: Saves the flowerShop before quitting the app
    @Override
    public void popupYesConfirmation() {
        saveFlowerShop();
        printLog();
        quitPopup.hide();
        controller.dispose();
    }

    //EFFECTS: Quits the app
    @Override
    public void popupNoConfirmation() {
        printLog();
        quitPopup.hide();
        controller.dispose();
    }

    //EFFECTS: Prints a log of all session events to the console
    private void printLog() {
        EventLog el = EventLog.getInstance();
        for (Event next: el) {
            System.out.println(next.toString() + "\n");
        }
    }






}
