package ui.tabs;

import ui.FlowerShopAppUI;

import javax.swing.*;
import java.awt.*;

// Credits: The structure for this GUI was modeled after: https://github.students.cs.ubc.ca/CPSC210/AlarmSystem
// In all UI classes, extensive use was made of Oracle's Swing library documentation:
// https://docs.oracle.com/javase/8/docs/api/javax/swing/package-summary.html

// NOTE: This class was not implemented in the GUI under the requirements for Phase 3; this is a placeholder class
//       that is not needed to fulfill requirements for phase 3 nor is it intended to be marked for
//       phase 3 of CPSC 210's personal project, but will be implemented in the future outside of CPSC 210.

//Orders tab that is used to represent and manage the current and completed orders in a flowerShop.
public class OrdersTab extends Tab {

    //EFFECTS: constructs an orders tab with buttons
    public OrdersTab(FlowerShopAppUI controller) {
        super(controller);
        JLabel tempText = new JLabel("Order management coming soon...");
        tempText.setFont(new Font("serif", Font.PLAIN, 32));
        this.add(tempText);
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: defines the action for the yes action on the confirmation popup
    @Override
    public void popupYesConfirmation() {
        //STUB
    }

    //EFFECTS: defines the action for the no action on the confirmation popup
    @Override
    public void popupNoConfirmation() {
        //STUB
    }

    // MODIFIES: this
    // EFFECTS: updates the order tab to reflect the current state of the flowerShop
    public void updateTab() {
        //STUB
    }



}
