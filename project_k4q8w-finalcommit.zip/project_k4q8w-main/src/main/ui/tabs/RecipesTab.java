package ui.tabs;

import model.Plant;
import model.Recipe;
import ui.FlowerShopAppUI;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.List;

// Credits: The structure for this GUI was modeled after: https://github.students.cs.ubc.ca/CPSC210/AlarmSystem
// In all UI classes, extensive use was made of Oracle's Swing library documentation:
// https://docs.oracle.com/javase/8/docs/api/javax/swing/package-summary.html
// In this Class, https://www.baeldung.com/java-round-decimal-number was used as a resource for a way
// to round doubles

// Represents a recipe tab that displays and manages the recipes belonging to a flowerShop
public class RecipesTab extends Tab {

    private static final String ALL_RECIPES_LABEL = "All Recipes";

    private List<Plant> flowerShopPlants;
    private List<Recipe> flowerShopRecipes;

    private JComboBox filterOptions;
    private JList<String> recipeList;
    private JPanel filterPanel;
    private JPanel recipesListView;
    private JPanel recipeSummaryView;

    private JLabel summaryTextTitle;
    private JLabel summaryTextCost;
    private JLabel summaryTextPlants;

    private Popup deletePopup;

    //EFFECTS: constructs a recipe tab with buttons
    public RecipesTab(FlowerShopAppUI controller) {
        super(controller);
        setLayout(new GridLayout(3, 1));

        flowerShopPlants = flowerShop.getInventory();
        flowerShopRecipes = flowerShop.getAllRecipes();

        loadFilterEditButtons();
        loadRecipeView();
        loadDeleteAddRecipe();
    }

    //MODIFIES: this
    //EFFECTS: updates the filter options and recipe view to reflect current flowerShop status
    public void updateTab() {
        flowerShopPlants = flowerShop.getInventory();
        flowerShopRecipes = flowerShop.getAllRecipes();
        updateFilterOptions();
        updateSummaryText(getSelectedRecipe());
    }

    //MODIFIES: this
    //EFFECTS: places the Delete recipe and Add recipe buttons in the recipe tab
    private void loadDeleteAddRecipe() {
        JPanel deleteAddPanel = new JPanel();
        deleteAddPanel.setLayout(new GridLayout(1,2));
        JPanel addPanel = new JPanel();
        addPanel.setBackground(BACKGROUND_COLOR);
        JPanel deletePanel = new JPanel();
        deletePanel.setBackground(BACKGROUND_COLOR);

        JButton addRecipeButton = new JButton("Add new recipe");
        addRecipeAction(addRecipeButton);

        JButton deleteRecipeButton = new JButton("Delete this recipe");
        deleteRecipeAction(deleteRecipeButton);

        deletePanel.add(deleteRecipeButton);
        addPanel.add(addRecipeButton);
        deleteAddPanel.add(addPanel);
        deleteAddPanel.add(deletePanel);
        this.add(deleteAddPanel);
    }

    //EFFECTS: creates action listener for the button that deletes a recipe from the flowerShop
    private void deleteRecipeAction(JButton deleteRecipeButton) {
        deleteRecipeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletePopup = formatPopup("Are you sure you want to delete this recipe?");
                deletePopup.show();
            }
        });
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: deletes the currently selected recipe from the flower shop and updates the recipe list view
    @Override
    public void popupYesConfirmation() {
        Recipe recipe = getSelectedRecipe();
        flowerShop.removeRecipe(recipe);
        updateRecipeView((String) filterOptions.getSelectedItem());
        updateSummaryText(null);
        deletePopup.hide();
    }

    //EFFECTS: closes the delete confirmation popup
    @Override
    public void popupNoConfirmation() {
        deletePopup.hide();
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: creates action listener
    //          that creates a new dialog box to use user input to add a new recipe to the flowerShop
    private void addRecipeAction(JButton addRecipeButton) {
        //EFFECTS: Creates a dialog window that prompts the user to create a new recipe
        addRecipeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton confirmButton = new JButton("Confirm");
                JTextField input = new JTextField();
                JDialog newRecipeDialog = formatDialogInputBox("Add new recipe",
                        "Enter new recipe name:", confirmButton, input);

                //MODIFIES: flowerShop, this
                //EFFECTS: Creates a new recipe, adds it to the flowerShop, and updates the recipe tab view
                confirmButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String name = input.getText();
                        Recipe recipe = new Recipe(name);
                        flowerShop.addRecipe(recipe);
                        updateRecipeView((String) filterOptions.getSelectedItem());
                        newRecipeDialog.setVisible(false);
                    }
                });
                newRecipeDialog.setVisible(true);
            }
        });
    }

    //MODIFIES: this
    //EFFECTS: Creates the recipe tab top panel with a recipe filter combo box and recipe editing buttons
    private void loadFilterEditButtons() {
        JPanel filterEditPanel = new JPanel();
        filterEditPanel.setBackground(BACKGROUND_COLOR);
        filterEditPanel.setLayout(new GridLayout(1,2));
        filterPanel = makeFilterPanel();
        JPanel editPanel = new JPanel();
        editPanel.setLayout(new GridLayout(2,2));
        filterEditPanel.add(filterPanel);
        filterEditPanel.add(editPanel);

        JButton addPlantButton = new JButton("Add a plant");
        addPlantAction(addPlantButton);

        JButton removePlantButton = new JButton("Remove a plant");
        removePlantAction(removePlantButton);

        JButton changeMaterialsButton = new JButton("Update material costs");
        updateMaterialsButtonAction(changeMaterialsButton);

        JButton changeNameButton = new JButton("Change Recipe Name");
        changeRecipeNameAction(changeNameButton);

        editPanel.add(addPlantButton);
        editPanel.add(removePlantButton);
        editPanel.add(changeMaterialsButton);
        editPanel.add(changeNameButton);
        this.add(filterEditPanel);
    }

    //MODIFIES: FlowerShop, this
    //EFFECTS: creates action listener that makes and displays the dialog box to change the recipe material cost
    private void updateMaterialsButtonAction(JButton changeMaterialsButton) {
        //EFFECTS: Creates a dialog box that prompts the user to enter a new material cost for the currently
        //          selected recipe.
        changeMaterialsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JTextField costInput = new JTextField();
                JButton confirmButton = new JButton("Confirm");
                JDialog materialDialog = formatDialogInputBox("Update material cost",
                        "Enter the new material cost: ", confirmButton, costInput);

                //MODIFIES: flowerShop, this
                //EFFECTS: Updates the current recipe's material cost and the recipe summary display
                confirmButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            getSelectedRecipe().setMaterialCost(Double.parseDouble(costInput.getText()));
                        } catch (NullPointerException i) {
                            materialDialog.setVisible(false);
                            return;
                        }
                        updateSummaryText(getSelectedRecipe());
                        materialDialog.setVisible(false);
                    }
                });

                materialDialog.setVisible(true);
            }
        });
    }

    //MODIFIES this, flowerShop
    //EFFECTS: creates an action listener with a dialog box that gets user input and changes the recipe name
    private void changeRecipeNameAction(JButton changeNameButton) {
        //EFFECTS: Creates a dialog box that prompts the user for a new recipe name
        changeNameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton confirmButton = new JButton("Confirm");
                JTextField inputField = new JTextField();
                JDialog nameDialog = formatDialogInputBox("Change recipe name",
                        "Enter the new recipe name: ", confirmButton, inputField);

                //MODIFIES: this, flowerShop
                //EFFECTS: updates the name of the current recipe based on user input and updates recipe summary text
                confirmButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            getSelectedRecipe().setName(inputField.getText());
                        } catch (NullPointerException i) {
                            nameDialog.setVisible(false);
                            return;
                        }
                        updateTab();
                        nameDialog.setVisible(false);
                    }
                });

                nameDialog.setVisible(true);
            }
        });
    }

    //MODIFIES: this
    //EFFECTS: sets up and displays dialog box to prompt user to remove a plant from the selected recipe
    private void removePlantAction(JButton removePlantButton) {
        removePlantButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Recipe recipe = getSelectedRecipe();
                List<String> recipePlants = recipe.getPlantNamesInRecipe();
                JDialog removePlantDialog = new JDialog(controller, "Add a plant");
                removePlantDialog.setSize(600,300);
                removePlantDialog.setLayout(new GridLayout(3,1));

                DefaultListModel<String> plantNames = new DefaultListModel<>();
                for (String next: recipePlants) {
                    plantNames.addElement(next);
                }
                JList<String> plantOptionList = new JList(plantNames);
                JLabel prompt = new JLabel("Choose the plant to remove");
                JButton confirm = new JButton("Confirm");

                removePlantConfirm(confirm, removePlantDialog, plantOptionList);

                removePlantDialog.add(prompt);
                removePlantDialog.add(plantOptionList);
                removePlantDialog.add(confirm);
                removePlantDialog.setVisible(true);

            }
        });
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: removes the plant selected by the user from the user selected recipe
    private void removePlantConfirm(JButton confirm, JDialog removePlantDialog, JList plantOptionList) {
        confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String plantName = (String) plantOptionList.getSelectedValue();
                Recipe recipe = getSelectedRecipe();
                try {
                    recipe.removePlant(flowerShop.findPlant(plantName));
                } catch (NullPointerException | IndexOutOfBoundsException i) {
                    removePlantDialog.setVisible(false);
                }
                updateSummaryText(recipe);
                removePlantDialog.setVisible(false);
            }
        });
    }

    //EFFECTS: adds an action listener for the add a plant to recipe button
    private void addPlantAction(JButton addPlantButton) {
        addPlantButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buildPlantCheckBox(getSelectedRecipe());
            }
        });


    }

    //MODIFIES: this
    //EFFECTS: Builds the dialog box that lets a user add a plant to the recipe
    private void buildPlantCheckBox(Recipe recipe) {
        JDialog addPlantDialog = new JDialog(controller, "Add a plant");
        addPlantDialog.setSize(600,600);
        addPlantDialog.setLayout(new GridLayout(3,1));

        DefaultListModel<String> plantNames = new DefaultListModel<>();
        for (Plant next: flowerShopPlants) {
            plantNames.addElement(next.getName());
        }
        JList<String> plantOptionList = new JList(plantNames);
        JScrollPane scrollList = new JScrollPane();
        scrollList.setViewportView(plantOptionList);

        JPanel inputPanel = new JPanel(new GridLayout(1,2));
        JLabel prompt = new JLabel("Enter the number of stems needed");
        JTextField input = new JTextField();

        JButton confirm = new JButton("Confirm");
        addPlantConfirm(confirm, recipe, plantOptionList, input, addPlantDialog);

        inputPanel.add(prompt);
        inputPanel.add(input);
        addPlantDialog.add(scrollList);
        addPlantDialog.add(inputPanel);
        addPlantDialog.add(confirm);
        addPlantDialog.setVisible(true);
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: Uses user inputs to add a new plant with the specified stem count to the flowerShop
    private void addPlantConfirm(JButton confirm, Recipe recipe,
                                 JList plantOptionList, JTextField input, JDialog dialog) {
        confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String plantName = (String) plantOptionList.getSelectedValue();
                Plant plant = flowerShop.findPlant(plantName);
                int stems = Integer.parseInt(input.getText());
                try {
                    recipe.addPlant(plant, stems);
                } catch (NullPointerException | IndexOutOfBoundsException i) {
                    dialog.setVisible(false);
                    return;
                }
                updateSummaryText(recipe);
                dialog.setVisible(false);
            }
        });
    }

    //MODIFIES: this
    //EFFECT: Updates the filter options to reflect current flowerShop plants and updates
    //        recipe list view to match
    private void updateFilterOptions() {
        filterPanel.remove(filterOptions);
        filterOptions = new JComboBox<>();

        //MODIFIES: this
        //EFFECTS: Updates the recipe summary view based on the currently selected recipe.
        filterOptions.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateRecipeView((String) filterOptions.getSelectedItem());
            }
        });

        filterOptions.addItem(ALL_RECIPES_LABEL);
        for (Plant next: flowerShopPlants) {
            filterOptions.addItem(next.getName());
        }

        filterPanel.add(filterOptions);
        updateRecipeView((String) filterOptions.getSelectedItem());
    }

    //EFFECTS: returns a list of recipe names that include the plant matching label
    private DefaultListModel<String> filterRecipes(String label) {
        DefaultListModel<String> recipeNames = new DefaultListModel<>();
        if (label.equals(ALL_RECIPES_LABEL)) {
            for (Recipe next: flowerShopRecipes) {
                recipeNames.addElement(next.getName());
            }
        } else {
            Plant plant = flowerShop.findPlant(label);
            List<Recipe> filteredRecipes = flowerShop.searchRecipesByPlant(plant);
            for (Recipe next: filteredRecipes) {
                recipeNames.addElement(next.getName());
            }
        }
        return recipeNames;
    }

    //MODIFIES: this
    //EFFECTS: updates the recipe list view to reflect the options in the flowerShop's recipes that
    //         include the filter's current selection
    private void updateRecipeView(String label) {
        DefaultListModel<String> recipeNames = filterRecipes(label);
        recipesListView.remove(recipeList);
        recipesListView.remove(recipeSummaryView);
        recipeList = new JList<>(recipeNames);
        recipeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        recipesListView.add(recipeList);
        recipesListView.add(recipeSummaryView);

        //MODIFIES: this
        //EFFECTS: Updates the recipe summary text to match the currently selected recipe
        recipeList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                Recipe recipe = getSelectedRecipe();
                updateSummaryText(recipe);

            }
        });
    }

    //EFFECTS: returns the recipe matching the current selection in the recipe viewing list
    private Recipe getSelectedRecipe() {
        flowerShopRecipes = flowerShop.getAllRecipes();
        String recipeName = recipeList.getSelectedValue();
        return flowerShop.findRecipe(recipeName);
    }

    //MODIFIES: this
    //EFFECTS: creates a JPanel with formatted blank JLabels for recipe summaries
    private JPanel initializeSummaryText() {
        JPanel recipesSummaryView = new JPanel();
        recipesSummaryView.setLayout(new GridLayout(3,1));
        recipesSummaryView.setBackground(BACKGROUND_COLOR);

        summaryTextTitle = new JLabel("");
        summaryTextTitle.setFont(new Font("serif", Font.PLAIN, 24));
        summaryTextCost = new JLabel("");
        summaryTextCost.setFont(new Font("serif", Font.PLAIN, 18));
        summaryTextPlants = new JLabel("");
        summaryTextPlants.setFont(new Font("serif", Font.PLAIN, 18));

        recipesSummaryView.add(summaryTextTitle);
        recipesSummaryView.add(summaryTextCost);
        recipesSummaryView.add(summaryTextPlants);

        return recipesSummaryView;
    }

    //MODIFIES: this
    //EFFECTS: Formats summary text for the Recipe
    private void updateSummaryText(Recipe recipe) {
        if (recipe == null) {
            summaryTextTitle.setText("");
            summaryTextCost.setText("");
            summaryTextPlants.setText("");
            return;
        }
        String name = recipe.getName();
        DecimalFormat df = new DecimalFormat("#####.##");
        String totalCost = String.valueOf(df.format(recipe.calculatePrice()));
        summaryTextTitle.setText("Recipe Summary: " + name);
        summaryTextCost.setText("Total cost: $" + totalCost);
        summaryTextPlants.setText(formatPlantText(recipe));
    }

    //MODIFIES: this
    //EFFECTS: Formats the plant list string for the current recipe
    private String formatPlantText(Recipe recipe) {
        String plantSummary = "";
        List<Plant> plants = recipe.getPlantsNeeded();
        for (Plant next: plants) {
            plantSummary =  plantSummary + "    " + next.getName() + ": " + recipe.getStemsNeededForPlant(next);
        }
        return plantSummary;
    }

    //MODIFIES: this
    //EFFECTS: Initializes the options of plants to filter recipes by according to flowerShop's available plants
    private JPanel makeFilterPanel() {
        filterOptions = new JComboBox();
        JLabel filterPrompt = new JLabel("Filter recipes by plant type: ");
        filterPrompt.setFont(new Font("serif", Font.PLAIN, 18));
        JPanel filterPanel = formatRow(filterPrompt);
        filterPanel.setLayout(new GridLayout(1,2));
        filterPanel.add(filterOptions);

        filterOptions.addItem(ALL_RECIPES_LABEL);

        for (Plant next: flowerShopPlants) {
            filterOptions.addItem(next.getName());
        }

        //MODIFIES: this
        //EFFECTS: Updates the recipe list view based on which plant is currently selected
        filterOptions.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateRecipeView((String) filterOptions.getSelectedItem());
            }
        });

        this.filterOptions = filterOptions;
        return filterPanel;
    }

    //MODIFIES: this
    //EFFECTS: loads and displays the list of available recipes
    private void loadRecipeView() {
        recipesListView = new JPanel();
        recipesListView.setLayout(new GridLayout(1,2));
        recipesListView.setBackground(BACKGROUND_COLOR);
        recipeSummaryView = initializeSummaryText();
        DefaultListModel<String> recipeNames = new DefaultListModel<>();
        for (Recipe next: flowerShopRecipes) {
            recipeNames.addElement(next.getName());
        }
        recipeList = new JList(recipeNames);
        recipeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        recipesListView.add(recipeList);

        //MODIFIES: this
        //EFFECTS: updates the recipe summary when a new recipe is selected
        recipeList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                Recipe recipe = getSelectedRecipe();
                updateSummaryText(recipe);
            }
        });
        recipesListView.add(recipeSummaryView);
        this.add(recipesListView);
    }





}
