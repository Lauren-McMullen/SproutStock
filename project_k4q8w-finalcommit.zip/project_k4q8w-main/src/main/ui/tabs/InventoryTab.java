package ui.tabs;

import model.Plant;
import ui.FlowerShopAppUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

// Credits: The structure for this GUI was modeled after: https://github.students.cs.ubc.ca/CPSC210/AlarmSystem
// In all UI classes, extensive use was made of Oracle's Swing library documentation:
// https://docs.oracle.com/javase/8/docs/api/javax/swing/package-summary.html

// Inventory tab that manages and displays all data relating to the plants in stock in a FlowerShop.

public class InventoryTab extends Tab {

    private List<Plant> flowerShopPlants;

    private JComboBox<String> plantDropBox;
    private JPanel dropDownRow;
    private JLabel summary;
    private JTextField newPlantNameField;
    private JTextField newPlantPriceField;
    private JTextField newPlantCountField;
    private Popup deletePopup;

    //EFFECTS: constructs a plants tab with appropriate buttons to manage the inventory
    public InventoryTab(FlowerShopAppUI controller) {
        super(controller);
        setLayout(new GridLayout(4, 1));

        flowerShopPlants = flowerShop.getInventory();

        loadNewPlantButton();

        dropDownRow = loadPlantDropBox();
        this.add(dropDownRow);

        initializePlantSummary();
        loadEditOptions();
    }

    //MODIFIES: this
    //EFFECTS: gets the most current flowerShop inventory and loads updated data into the dropbox and summary text
    public void updateTab() {
        flowerShopPlants = flowerShop.getInventory();
        updateDropBox();
        updatePlantSummary();
    }

    //MODIFIES: this
    //EFFECTS: Adds the "new plant" button and its action listener to this
    private void loadNewPlantButton() {
        JButton newPlantButton = new JButton("Add a new plant");
        JPanel buttonRow = formatRow(newPlantButton);

        //MODIFIES: this
        // EFFECTS: Creates a JDialog box that appears when the new plant button is clicked
        newPlantButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog newPlantDialog = new JDialog(controller, "Make a new plant");
                newPlantDialog.setSize(600,200);
                newPlantDialog.setLayout(new GridLayout(2, 1));
                JPanel newPlantPanel = formatNewPlantInputPanel();
                JButton newPlantConfirm = new JButton("Add Plant");
                newPlantDialog.add(newPlantPanel);
                newPlantDialog.add(newPlantConfirm);

                newPlantConfirm.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        makeNewPlant();
                        newPlantDialog.setVisible(false);
                    }
                });


                newPlantDialog.setVisible(true);
            }
        });
        this.add(buttonRow);
    }

    //MODIFIES: this
    //EFFECTS: Creates and formats components for the make new plant dialog box
    private JPanel formatNewPlantInputPanel() {
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3,2));

        JLabel namePrompt = new JLabel("Enter plant name: ");
        JLabel pricePrompt = new JLabel("Enter plant stem price: ");
        JLabel countPrompt = new JLabel("Enter plant stem count: ");

        newPlantNameField = new JTextField();
        newPlantPriceField = new JTextField();
        newPlantCountField = new JTextField();

        inputPanel.add(namePrompt);
        inputPanel.add(newPlantNameField);

        inputPanel.add(pricePrompt);
        inputPanel.add(newPlantPriceField);

        inputPanel.add(countPrompt);
        inputPanel.add(newPlantCountField);

        return inputPanel;
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: uses input from this text fields to create and add a new plant to the flowerShop, then updates UI
    private void makeNewPlant() {
        String name = newPlantNameField.getText();
        String priceString = newPlantPriceField.getText();
        double price = Double.parseDouble(priceString);
        String countString = newPlantCountField.getText();
        int count = Integer.parseInt(countString);
        Plant plant = new Plant(name, price, count);
        flowerShop.addInventory(plant);
        controller.setFlowerShop(flowerShop);
        HomeTab hometab = (HomeTab) controller.getHomeTab();
        hometab.updateTabs();
    }

    //MODIFIES: this
    //EFFECT: Creates the initialized dropdown menu for flowers in the inventory
    private JPanel loadPlantDropBox() {
        JComboBox flowerBox = new JComboBox<>();
        JLabel dropdownLabel = new JLabel();
        dropdownLabel.setText("View or Edit current inventory");
        dropdownLabel.setFont(new Font("serif", Font.PLAIN, 25));
        JPanel dropdownRow = formatRow(dropdownLabel);
        dropdownRow.add(flowerBox);

        for (Plant next: flowerShopPlants) {
            flowerBox.addItem(next.getName());
        }

        //EFFECTS: when a new plant is selected from the dropbox, updates the plant summary currently displayed
        flowerBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updatePlantSummary();
            }
        });

        plantDropBox = flowerBox;
        return dropdownRow;

    }

    //MODIFIES: this
    //EFFECTS: Updates the dropbox options based on current flowerShop inventory
    private void updateDropBox() {
        dropDownRow.remove(plantDropBox);
        plantDropBox = new JComboBox<>();

        //EFFECTS: when a new plant is selected from the dropbox, updates the plant summary currently displayed
        plantDropBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updatePlantSummary();
            }
        });

        for (Plant next: flowerShopPlants) {
            plantDropBox.addItem(next.getName());
        }
        dropDownRow.add(plantDropBox);
    }

    //MODIFIES: this
    //EFFECTS: Displays the initial plant summary for the first plant in the dropdown menu when the app is opened
    private void initializePlantSummary() {
        JPanel summaryPanel = new JPanel();
        summaryPanel.setLayout(new GridLayout(1,2));
        summaryPanel.setBackground(BACKGROUND_COLOR);
        JLabel summary = new JLabel("", JLabel.CENTER);
        summary.setText("");
        summary.setFont(new Font("serif", Font.PLAIN, 24));
        this.summary = summary;
        summaryPanel.add(summary);
        this.add(summaryPanel);
    }

    //MODIFIES: this
    //EFFECTS: Displays the summary of the plant currently selected in the dropdown menu
    private void updatePlantSummary() {
        Plant currentPlant = getCurrentPlant();
        if (currentPlant == null) {
            summary.setText("");
            return;
        }
        summary.setText("   " + currentPlant.getPlantSummary() + "    ");
        summary.setFont(new Font("serif", Font.PLAIN, 24));
    }

    //EFFECT: returns the plant currently selected in the flower dropdown box
    private Plant getCurrentPlant() {
        String currentPlantName = (String) plantDropBox.getSelectedItem();
        return flowerShop.findPlant(currentPlantName);
    }

    //MODIFIES: this
    //EFFECTS: Creates and adds the button row for editing options for the plants
    private void loadEditOptions() {
        JButton price = new JButton("Change stem price");
        stemPriceAction(price);

        JButton addStems = new JButton("Add stems to stock");
        addStemsAction(addStems);

        JButton sellStems = new JButton("Sell stems");
        sellStemsAction(sellStems);

        JButton delete = new JButton("Delete plant from inventory");
        deletePlantAction(delete);

        JPanel editOptions = formatRow(price);
        editOptions.add(addStems);
        editOptions.add(sellStems);
        editOptions.add(delete);
        this.add(editOptions);
    }

    //MODIFIES: flowerShop, this
    //EFFECTS: creates action listener that
    // sets up the panel for the stem price dialog box to update plant price in this flowerShop inventory
    private void stemPriceAction(JButton price) {

        //EFFECTS: Opens a new dialog box that allows the user to specify a new stem price.
        price.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JTextField input = new JTextField();
                JButton confirm = new JButton("Confirm price");
                JDialog priceBox = formatDialogInputBox("Update plant price", "Enter new price: ",
                        confirm, input);

                //MODIFIES: flowerShop, this
                //EFFECTS: changes the stem price of the currently selected plant to match user input
                confirm.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            getCurrentPlant().changePrice(Double.parseDouble(input.getText()));
                        } catch (NullPointerException i) {
                            priceBox.setVisible(false);
                            return;
                        }
                        updatePlantSummary();
                        priceBox.setVisible(false);
                    }
                });

                priceBox.setVisible(true);
            }
        });
    }

    //MODIFIES: flowerShop, this
    //EFFECTS: Creates action listener that sets up the panel for the stem price dialog box to add to the
    //         plant count in this flowerShop inventory
    private void addStemsAction(JButton addStems) {
        //EFFECTS: Creates and opens a dialog box for adding stems to inventory.
        addStems.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JTextField input = new JTextField();
                JButton confirm = new JButton("Add stems");
                JDialog addStemBox = formatDialogInputBox("Add Stems",
                        "Enter the number of stems to add: ", confirm, input);

                //MODIFIES: flowerShop, this
                //EFFECTS: Adds stems to the currently selected plant stem count based on user input
                confirm.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            getCurrentPlant().addStock(Integer.parseInt(input.getText()));
                        } catch (NullPointerException i) {
                            addStemBox.setVisible(false);
                            return;
                        }
                        updatePlantSummary();
                        addStemBox.setVisible(false);
                    }
                });

                addStemBox.setVisible(true);
            }
        });
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: Creates action listener that sets up the panel for the stem price dialog box to subtract from
    //         the plant count in this flowerShop inventory
    private void sellStemsAction(JButton sellStems) {
        //EFFECTS: Creates a dialog box for removing stems from inventory.
        sellStems.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JTextField input = new JTextField();
                JButton confirm = new JButton("Sell stems");
                JDialog sellStemBox = formatDialogInputBox("Sell Stems",
                        "Enter the number of stems to sell: ", confirm, input);

                //MODIFIES: flowerShop, this
                //EFFECTS: removes stems from the count of currently selected plant stems based on user input
                confirm.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            getCurrentPlant().sellStems(Integer.parseInt(input.getText()));
                        } catch (NullPointerException i) {
                            sellStemBox.setVisible(false);
                            return;
                        }
                        updatePlantSummary();
                        sellStemBox.setVisible(false);
                    }
                });

                sellStemBox.setVisible(true);
            }
        });
    }

    //EFFECTS: displays the delete plant confirmation popup when the delete plant button is pressed
    private void deletePlantAction(JButton delete) {
        //EFFECTS: Creates a popup that asks for confirmation when the delete plant button is pressed.
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletePopup = formatPopup("Are you sure you want to delete this plant?");
                deletePopup.show();
            }
        });
    }

    //MODIFIES: this, flowerShop
    //EFFECTS: Deletes the plant from the flowerShop and
    //         updates the UI to reflect the deletion
    @Override
    public void popupYesConfirmation() {
        Object item = plantDropBox.getSelectedItem();
        String plantName = (String) item;
        Plant plant = flowerShop.findPlant(plantName);
        plantDropBox.removeItem(item);

        flowerShop.removeInventory(plant);
        controller.setFlowerShop(flowerShop);

        HomeTab hometab = (HomeTab) controller.getHomeTab();
        hometab.updateTabs();

        deletePopup.hide();
    }

    //EFFECTS: Hides the quit confirmation popup
    @Override
    public void popupNoConfirmation() {
        deletePopup.hide();
    }


}
