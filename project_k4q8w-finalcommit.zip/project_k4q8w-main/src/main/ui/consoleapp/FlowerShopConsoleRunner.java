package ui.consoleapp;

// Main class that runs the program using the Flower Shop App.

public class FlowerShopConsoleRunner {

    public static void main(String[] args) {
        FlowerShopApp fs = new FlowerShopApp();
    }
}



