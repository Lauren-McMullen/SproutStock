package ui.consoleapp.consolemenus;

import model.FlowerShop;
import model.Plant;
import model.Recipe;

import java.util.List;

// Represents the actions that can be taken through the Recipe menu in the flower shop app, including displaying the
// recipe menu, making a new recipe, editing a recipe, searching recipes by name or plant type, and displaying all
// recipes

public class RecipeMenu extends UserMenu {

    private final FlowerShop flowerShop;

    // Create a new Recipe menu with an initialized scanner to read user input and a flower shop
    public RecipeMenu(FlowerShop flowerShop) {
        input = initializeScanner();
        this.flowerShop = flowerShop;
    }

    //EFFECTS: Displays recipe menu options.
    public void menuDisplay() {
        System.out.println("Create, edit, and delete recipes!");
        System.out.println("v -> View all recipes in your shop");
        System.out.println("s -> Search for a recipe by name");
        System.out.println("p -> Search for a recipe by plant type");
        System.out.println("n -> Add a new recipe to your shop");
        System.out.println("r -> Remove a recipe from your shop");
        System.out.println("e -> Edit a recipe");
        System.out.println("m -> Return to main menu");
    }

    //EFFECTS: Displays menu options when editing a recipe.
    public void recipeEditingMenuDisplay() {
        System.out.println("Choose an editing option: ");
        System.out.println("n -> Change Recipe Name");
        System.out.println("c -> Update material costs");
        System.out.println("a -> Add a new plant to the recipe");
        System.out.println("x -> Remove a plant from the recipe");
        System.out.println("r -> Return to the recipe menu");
    }

    //MODIFIES: flowerShop
    //EFFECTS: Uses user input to create a new recipe and adds it to the flower shop
    public void makeNew() {
        Recipe newRecipe = newRecipeUserSetup();
        Recipe recipe = addPlantsToRecipe(newRecipe);
        flowerShop.addRecipe(recipe);
        System.out.println("Successfully created recipe!");
    }

    //MODIFIES: Recipe
    //EFFECT: Helper method that gathers details from the user to set up a new recipe with just the name and
    // material cost
    private Recipe newRecipeUserSetup() {
        System.out.println("Enter the name of the new recipe:");
        Recipe newRecipe = new Recipe(input.next());
        double cost = getValidDouble("Enter the cost of non-plant materials in this recipe (vase, tape, etc.):");
        newRecipe.setMaterialCost(cost);
        return newRecipe;
    }

    //MODIFIES: Recipe
    //EFFECTS: Adds user-input plant(s) to the recipe
    public Recipe addPlantsToRecipe(Recipe recipe) {
        boolean addPlants = true;
        while (addPlants) {
            System.out.println("Enter the name of a plant to add: ");
            String plantName = input.next();
            Plant plant = flowerShop.findPlant(plantName);
            if (plant == null) {
                System.out.println("Error: " + plantName + " is not in your inventory. Please add this plant to"
                        + " your inventory and before adding it to a recipe via the recipe editing menu.");
                return recipe;
            }
            int stems = getValidInteger("Enter how many " + plantName + " stems needed in this recipe:");
            recipe.addPlant(plant, stems);
            System.out.println("Plant successfully added!");
            System.out.println("Would you like to add more plants to this recipe? Enter 'n' for no. Otherwise, "
                    + "enter anything else to continue adding plants.:");
            String plantDecision = input.next().toLowerCase();
            if (plantDecision.equals("n")) {
                addPlants = false;
            }
        }
        return recipe;
    }

    //EFFECTS: Displays the summaries of the recipes in the flower shop that match the user-given name.
    public void searchByName() {
        System.out.println("Enter the name of the recipe you are looking for:");
        String recipeName = input.next();
        List<Recipe> recipes = flowerShop.searchRecipesByName(recipeName);
        if (recipes.isEmpty()) {
            System.out.println("Sorry - no recipes match this name.");
        } else {
            System.out.println(flowerShop.recipesSummary(recipes));
        }
    }

    //EFFECTS: Displays the summaries of the recipes in the flower shop that include the plant type given by the user.
    public void searchByPlant() {
        System.out.println("Enter the plant you would like to find recipes for:");
        String plantName = input.next();
        Plant plant = flowerShop.findPlant(plantName);
        List<Recipe> recipes = flowerShop.searchRecipesByPlant(plant);
        if (recipes.isEmpty()) {
            System.out.println("Sorry - no recipes found with " + plantName);
        } else {
            System.out.println(flowerShop.recipesSummary(recipes));
        }
    }

    //MODIFIES: flowerShop
    //EFFECTS: Uses user input to remove a recipe from the flower shop
    public void removeRecipe() {
        System.out.println("Enter the name of the recipe you would like to delete: ");
        String recipeName = input.next();
        Recipe recipeToRemove = flowerShop.findRecipe(recipeName);
        if (recipeToRemove == null) {
            System.out.println("Deletion failed: there are no recipes named " + recipeName + " in your flower shop.");
        } else {
            flowerShop.removeRecipe(recipeToRemove);
            System.out.println("Success! " + recipeName + " has been deleted from your available recipes.");
        }
    }

    //MODIFIES: Recipe
    //EFFECTS: Updates the name of the user-chosen recipe to the user-inputted name.
    public void changeName(Recipe recipe) {
        System.out.println("Enter the new name for the recipe: ");
        String recipeName = input.next();
        recipe.setName(recipeName);
        System.out.println("Name change successful! This recipe is not called: " + recipe.getName());
    }

    //MODIFIES: Recipe
    //EFFECTS: Sets the updated user-inputted material cost for the recipe in flower shop
    public void setMaterialCost(Recipe recipe) {
        double materialCost = getValidDouble("Enter the new material cost for the recipe: ");
        recipe.setMaterialCost(materialCost);
        System.out.println("Material cost change successful! The material costs are now: $" + recipe.getMaterialCost());
    }

    //MODIFIES: Recipe
    //EFFECTS: Removes user-input plant(s) from the recipe. If the plant does not exist in the recipe, the user gets
    // an error message.
    public void removePlant(Recipe recipeToEdit) {
        System.out.println("Enter the name of the plant to remove: ");
        String nameOfPlant = input.next();
        Plant plantToRemove = recipeToEdit.findPlant(nameOfPlant);
        if (plantToRemove == null) {
            System.out.println("Error: There is not plant matching this name in " + recipeToEdit.getName());
        } else {
            recipeToEdit.removePlant(plantToRemove);
            System.out.println("Success! " + nameOfPlant + " had been removed from " + recipeToEdit.getName());
        }
    }
}
