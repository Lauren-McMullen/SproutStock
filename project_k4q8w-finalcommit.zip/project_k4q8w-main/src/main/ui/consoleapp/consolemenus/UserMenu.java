package ui.consoleapp.consolemenus;

import java.util.Scanner;
// Abstract class that initializes the input scanner, defines menu displays,
// and implements user input type checks for the menu subtypes
// CREDIT: Documentation for the .next(), .nextDouble(), and .nextInt() methods for the scanner were found on
// https://www.javatpoint.com/post/java-scanner-hasnextdouble-method and
// https://stackoverflow.com/questions/3059333/validating-input-using-java-util-scanner

public abstract class UserMenu {

    protected Scanner input;

    //EFFECTS: Displays menu options.
    protected abstract void menuDisplay();

    //EFFECTS: Makes a new instance of the class in the flower shop that matches to the subclass menu.
    //         RecipeMenu -> Makes a new Recipe using user input
    //         PlantMenu -> Makes a new Plant using user input
    //         OrderMenu -> Makes a new Order using user input
    protected abstract void makeNew();

    //MODIFIES: this
    //EFFECTS: Creates a new scanner to read user input
    protected Scanner initializeScanner() {
        input = new Scanner(System.in);
        input.useDelimiter("\n");
        return input;
    }

    protected int getValidInteger(String message) {
        int count = 0;
        boolean moveOn = false;
        while (!moveOn) {
            System.out.println(message);
            while (!input.hasNextInt()) {
                System.out.println("Invalid input: Please enter a positive integer number.");
                input.next();
            }
            count = input.nextInt();
            if (count >= 0) {
                moveOn = true;
            } else {
                System.out.println("Invalid input: Please enter a positive integer: ");
            }
        }
        return count;
    }


    //EFFECTS: Ensures that user input is a double before subsequent code is executed.
    protected double getValidDouble(String message) {
        double count = 0;
        boolean moveOn = false;
        while (!moveOn) {
            System.out.println(message);
            while (!input.hasNextDouble()) {
                System.out.println("Invalid input: Please enter a number greater than 0: ");
                input.next();
            }
            count = input.nextDouble();
            if (count > 0) {
                moveOn = true;
            } else {
                System.out.println("Invalid input: Please enter a number greater than 0: ");
            }
        }
        return count;
    }


}
