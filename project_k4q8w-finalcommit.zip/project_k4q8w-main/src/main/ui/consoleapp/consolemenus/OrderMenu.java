package ui.consoleapp.consolemenus;

import model.FlowerShop;
import model.Order;
import model.Recipe;

import java.util.ArrayList;
import java.util.List;

// Represents the actions that can be taken through the Order menu in the flower shop app, including displaying
// orders menu, searching for orders by number, fulfilling an order, and taking a new order.

public class OrderMenu extends UserMenu {

    private final FlowerShop flowerShop;

    //EFFECT: Creates a new order menu with an initialized scanner to read user input and a flower shop.
    public OrderMenu(FlowerShop flowerShop) {
        input = initializeScanner();
        this.flowerShop = flowerShop;
    }

    //EFFECTS: Displays order menu options to the user.
    public void menuDisplay() {
        System.out.println("Order up! View, search, add, and fulfill shop orders here.");
        System.out.println("v -> View all current orders in your shop");
        System.out.println("x -> View all completed orders in your shop");
        System.out.println("s -> Search for an order by order number");
        System.out.println("f -> fulfill an order");
        System.out.println("n -> take a new order");
        System.out.println("m -> Return to main menu");
    }

    //EFFECTS: Prints the summary of the order that matches the user-specified order number. The user will
    // receive an error if the inputted order number does not exist in the flower shop.
    public void searchOrder() {
        int orderNumber = getValidInteger("Enter the Order number you would like to search for: ");
        Order order = flowerShop.findOrder(orderNumber);
        if (order == null) {
            errorMessageNoOrder(orderNumber);
        } else {
            System.out.println(order.orderSummary());
        }
    }

    //MODIFIES: flowerShop, order
    //EFFECTS: Completes the order specified (by number) by the user. The user will
    // receive an error if they input an order number that does not exist.
    public void fulfillOrder() {
        int orderNumber = getValidInteger("Enter the Order number you would like to fulfill: ");
        Order order = flowerShop.findOrder(orderNumber);
        if (order == null) {
            errorMessageNoOrder(orderNumber);
            return;
        }
        boolean orderSuccess = order.makeOrder();
        if (orderSuccess) {
            flowerShop.completeOrder(order);
            System.out.println("Order successfully completed!");
        } else {
            System.out.println("Order could not be completed."
                    + " Please ensure you have enough stock to fulfill this order");
        }
    }

    //MODIFIES: flowerShop
    //EFFECTS: Creates a new order with a user inputted list of recipes to add to the order.
    public void makeNew() {
        List<Recipe> recipesToAdd = recipesToAdd();
        if (recipesToAdd.isEmpty()) {
            System.out.println("Action failed: you cannot create an order with no recipes.");
            return;
        }
        Order newOrder = new Order(recipesToAdd);
        flowerShop.addCurrentOrder(newOrder);
        System.out.println("Order successfully created!");
    }

    //EFFECTS: Iterates through user input to gather the recipes to add to an order until they no longer want to
    // add more recipes.
    // The user will receive an error if they try to add a recipe that does not exist in the flower shop.
    public List<Recipe> recipesToAdd() {
        boolean moreRecipes = true;
        List<Recipe> recipesToAdd = new ArrayList<>();
        while (moreRecipes) {
            System.out.println("Enter the name of the recipe you would like to add to your order: ");
            String recipeName = input.next();
            Recipe recipeToAdd = flowerShop.findRecipe(recipeName);
            if (recipeToAdd == null) {
                System.out.println("Error: no recipe matches this name.");
            } else {
                recipesToAdd.add(recipeToAdd);
            }
            System.out.println("Would you like to add more recipes?  Enter 'n' for no. Otherwise,"
                    + "enter anything else to continue adding recipes.");
            String moreOrderDecision = input.next().toLowerCase();
            if (moreOrderDecision.equals("n")) {
                moreRecipes = false;
            }
        }
        return recipesToAdd;
    }

    //EFFECTS: Prints an error message.
    public void errorMessageNoOrder(int orderNumber) {
        System.out.println("Error: No order in your store matches order number " + orderNumber);
    }

}
