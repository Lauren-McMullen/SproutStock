package ui.consoleapp.consolemenus;

import model.FlowerShop;
import model.Plant;




// Represents the actions that can be taken through the Plant menu in the flower shop app, including displaying menu
// options, making a new plant and adding it to the flower shop, removing plants from the flower shop, adding stems
// to the plant's inventory, updating the plant price, and selling stems.

public class PlantMenu extends UserMenu {

    private final FlowerShop flowerShop;

    // Create a new plant menu with an initialized scanner to read user input, and a flower shop
    public PlantMenu(FlowerShop flowerShop) {
        input = initializeScanner();
        this.flowerShop = flowerShop;
    }

    //EFFECTS: Displays plant menu options.
    public void menuDisplay() {
        System.out.println("Manage your plant inventory!");
        System.out.println("v -> View all plants in your inventory");
        System.out.println("n -> Add a new plant to your inventory");
        System.out.println("r -> Remove a plant from your inventory");
        System.out.println("u -> Update a plant price");
        System.out.println("b -> Add stock for an existing plant");
        System.out.println("s -> Sell plant stems");
        System.out.println("m -> Return to main menu");
    }

    //MODIFIES: flower shop
    //EFFECTS: makes a new plant as specified by user and adds it to this flower shop inventory.

    public void makeNew() {
        System.out.println("Enter plant name: ");
        String plantName = input.next();
        double stemPrice = getValidDouble("Enter the price per stem: ");
        int plantStems = getValidInteger("Enter the number of stems in stock:");
        Plant newPlant = new Plant(plantName, stemPrice, plantStems);
        if (flowerShop.addInventory(newPlant)) {
            System.out.println("Success! We have added " + newPlant.getPlantSummary() + " to your inventory");
        } else {
            System.out.println("Sorry! This plant is already in your inventory. "
                    + "Please navigate to the plant menu to add stock to an existing plant");
        }
    }

    //MODIFIES: flowerShop
    //EFFECTS: removes the plant specified from the user from the shop inventory. If the plant does not exist in
    // this shop, the user will get an error message.
    public void removePlant() {
        System.out.println("Enter the name of the plant you would like to remove from your inventory: ");
        String nameToRemove = input.next();
        Plant plantToRemove = flowerShop.findPlant(nameToRemove);
        if (plantToRemove == null) {
            errorMessageInventory();
        } else {
            flowerShop.removeInventory(plantToRemove);
            System.out.println("Success! " + nameToRemove + " has been removed.");
        }

    }

    //MODIFIES: flowerShop, plant
    //EFFECTS: Updates the price of the plant in the inventory that matches the given name. If the plant does not exist,
    // the user will get an error message.
    public void updatePlantPrice() {
        System.out.println("Enter the name of the plant you would like to update the price for: ");
        String nameOfPlantToUpdate = input.next();
        Plant plantToUpdate = flowerShop.findPlant(nameOfPlantToUpdate);
        double stemPrice = getValidDouble("Enter the new per stem price: ");
        if (plantToUpdate == null) {
            errorMessageInventory();
        } else {
            plantToUpdate.changePrice(stemPrice);
            System.out.println("Success! The price of " + nameOfPlantToUpdate + " is now: " + stemPrice);
        }

    }

    //MODIFIES: flowerShop, plant
    //EFFECTS: Add the user-specified number of stems to the user-specified plant in the inventory.
    public void addPlantStock() {
        System.out.println("Enter the name of the plant you would like to add stems of:");
        String nameOfPlant = input.next();
        Plant plantToAddStems = flowerShop.findPlant(nameOfPlant);
        int numberOfStems = getValidInteger("How many stems would you like to add?");
        if (nameOfPlant == null) {
            errorMessageInventory();
        } else {
            plantToAddStems.addStock(numberOfStems);
            System.out.println("Successfully added " + numberOfStems + " to the " + nameOfPlant + " inventory");
        }
    }

    //MODIFIES: flowerShop, plant
    //EFFECTS: Reduces the stock of the specified plant by the specified stem count.
    public void sellStems() {
        System.out.println("Enter the name of the plant that you would like to sell stems of: ");
        String nameOfPlantToSell = input.next();
        Plant plantToSell = flowerShop.findPlant(nameOfPlantToSell);
        int stemsToSell = getValidInteger("Enter the number of stems to sell: ");
        if (plantToSell == null) {
            errorMessageInventory();
        } else if (plantToSell.getStemStock() < stemsToSell) {
            System.out.println("Error: Cannot sell more stems than there are available.");
        } else {
            plantToSell.sellStems(stemsToSell);
            System.out.println("Success! " + stemsToSell + " " + nameOfPlantToSell
                    + " stems have sold and been removed from you inventory!");
        }
    }

    //EFFECTS: Prints an error message.
    public void errorMessageInventory() {
        System.out.println("Action Failed: This plant does not exist in your inventory");
    }


}
