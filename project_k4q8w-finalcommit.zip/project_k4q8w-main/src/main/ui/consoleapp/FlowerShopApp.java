package ui.consoleapp;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import model.FlowerShop;
import model.Recipe;
import persistence.JsonReader;
import persistence.JsonWriter;
import ui.consoleapp.consolemenus.OrderMenu;
import ui.consoleapp.consolemenus.PlantMenu;
import ui.consoleapp.consolemenus.RecipeMenu;

// Flower shop application that allows users to manage their plants, recipes, and orders
// CREDITS: Parts of this class structure (such as the scanner and the structure of a method to control
// the running of the app) were learned from the Teller App example via EdX and
// expanded/modified to suit this application.
// The structure of saving and loading mechanisms follows the example from the JsonSerializationDemo on CPSC210 EDx:
// https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo


public class FlowerShopApp {

    private FlowerShop flowerShop;

    private static final String JSON_STORE = "./data/myConsoleFlowerShop.json";
    private final JsonWriter jsonWriter;
    private final JsonReader jsonReader;


    private Scanner input;
    private PlantMenu plantMenu;
    private RecipeMenu recipeMenu;
    private OrderMenu orderMenu;

    // EFFECTS: Creates a new flower shop with the user given name, creates menus for Plant, Recipe,
    // and Order interaction, and runs the app for the new flower shop
    public FlowerShopApp() {
        initializeScanner();
        flowerShop = new FlowerShop("Sprout Stock");
        plantMenu = new PlantMenu(flowerShop);
        recipeMenu = new RecipeMenu(flowerShop);
        orderMenu = new OrderMenu(flowerShop);
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);
        runConsoleApp();


    }

    //MODIFIES: this
    //EFFECTS: Runs Flower Shop application.
    public void runConsoleApp() {
        boolean keepRunning = true;
        String command;
        System.out.println("Would you like to load previous save data? (y/n): ");
        String decision = input.next().toLowerCase();
        if (decision.equals("y")) {
            loadFlowerShop();
        }
        mainMenuDisplay();

        while (keepRunning) {
            command = initializeCommand();

            if (command.equals("q")) {
                System.out.println("Would you like to save before you quit? (y/n):");
                decision = input.next().toLowerCase();
                if (decision.equals("y")) {
                    saveFlowerShop();
                }
                keepRunning = false;
            } else {
                processMenuNavigation(command);
            }
        }
        System.out.println("Thank you for using SproutStock!");
    }

    //EFFECTS: Returns the current flower shop
    public FlowerShop getFlowerShop() {
        return this.flowerShop;
    }

    //EFFECTS: Displays main menu options that branch into Plant, Recipe, and Order displays.
    private void mainMenuDisplay() {
        System.out.println("Welcome to SproutStock! Please choose an option: ");
        System.out.println("p -> Plants");
        System.out.println("r -> Recipes");
        System.out.println("0 -> Orders");
        System.out.println("m -> Main Menu (Current)");
        System.out.println("s -> Save");
        System.out.println("l -> Load");
        System.out.println("q -> Quit App");
    }

    //EFFECTS: Processes user command to navigate them between menus
    public void processMenuNavigation(String command) {
        if (command.equals("m")) {
            mainMenuDisplay();
        } else if (command.equals("l")) {
            loadFlowerShop();
            mainMenuDisplay();
        } else if (command.equals("s")) {
            saveFlowerShop();
            mainMenuDisplay();
        } else if (command.equals("p")) {
            plantMenu.menuDisplay();
            processPlantCommand();
        } else if (command.equals("r")) {
            recipeMenu.menuDisplay();
            processRecipeCommand();
        } else if (command.equals("o")) {
            orderMenu.menuDisplay();
            processOrderCommand();
        } else {
            System.out.println(command + " is not a valid command. Please enter a new command.");
        }
    }

    //MODIFIES: this
    //EFFECTS: Processes user command within the plant menu display
    public void processPlantCommand() {
        String command = initializeCommand();
        if (command.equals("m")) {
            processMenuNavigation("m");
            return;
        } else if (command.equals("v")) {
            System.out.println(flowerShop.inventorySummary());
        } else if (command.equals("n")) {
            plantMenu.makeNew();
        }  else if (command.equals("r")) {
            plantMenu.removePlant();
        } else if (command.equals("u")) {
            plantMenu.updatePlantPrice();
        } else if (command.equals("b")) {
            plantMenu.addPlantStock();
        } else if (command.equals("s")) {
            plantMenu.sellStems();
        } else {
            System.out.println(command + " is not a valid command. Please enter a new command.");
        }
        processMenuNavigation("p");
    }

    //MODIFIES: this
    //EFFECTS: Processes user command within the recipe menu display
    private void processRecipeCommand() {
        String command = initializeCommand();
        if (command.equals("m")) {
            processMenuNavigation("m");
        } else if (command.equals("v")) {
            System.out.println(flowerShop.recipesSummary(flowerShop.getAllRecipes()));
            processMenuNavigation("r");
        } else if (command.equals("s")) {
            recipeMenu.searchByName();
            processMenuNavigation("r");
        } else if (command.equals("p")) {
            recipeMenu.searchByPlant();
            processMenuNavigation("r");
        } else if (command.equals("n")) {
            recipeMenu.makeNew();
            processMenuNavigation("r");
        } else if (command.equals("r")) {
            recipeMenu.removeRecipe();
            processMenuNavigation("r");
        } else if (command.equals("e")) {
            processRecipeEditingCommand();
        } else {
            System.out.println(command + " is not a valid command. Please enter a new command.");
        }
    }


    //MODIFIES: this
    //EFFECTS: Processes user command within the recipe editing menu display
    private void processRecipeEditingCommand() {
        Recipe recipeToEdit = getRecipeToEdit();
        if (recipeToEdit == null) {
            System.out.println("Error: No recipe found with this name.");
        } else {
            System.out.println("Successfully retrieved recipe! Currently editing: " + recipeToEdit.getName());
            recipeMenu.recipeEditingMenuDisplay();
            String command = initializeCommand();
            if (command.equals("n")) {
                recipeMenu.changeName(recipeToEdit);
            } else if (command.equals("c")) {
                recipeMenu.setMaterialCost(recipeToEdit);
            } else if (command.equals("a")) {
                recipeMenu.addPlantsToRecipe(recipeToEdit);
            } else if (command.equals("x")) {
                recipeMenu.removePlant(recipeToEdit);
            } else if (command.equals("r")) {
                processMenuNavigation("r");
            } else {
                System.out.println(command + " is not a valid command. Please enter a new command.");
            }
        }
    }

    //MODIFIES: this
    //EFFECTS: Processes user command within the order menu display
    private void processOrderCommand() {
        String command = initializeCommand();
        if (command.equals("m")) {
            processMenuNavigation("m");
            return;
        } else if (command.equals("v")) {
            System.out.println(flowerShop.ordersSummary(flowerShop.getCurrentOrders()));
        } else if (command.equals("x")) {
            System.out.println(flowerShop.ordersSummary(flowerShop.getCompletedOrders()));
        } else if (command.equals("s")) {
            orderMenu.searchOrder();
        } else if (command.equals("f")) {
            orderMenu.fulfillOrder();
        } else if (command.equals("n")) {
            orderMenu.makeNew();
        } else {
            System.out.println(command + " is not a valid command. Please enter a new command.");
        }
        processMenuNavigation("o");
    }


    //MODIFIES: input
    //EFFECTS: Helper method that initializes the Scanner used to read user input.
    private void initializeScanner() {
        input = new Scanner(System.in);
        input.useDelimiter("\n");
    }

    //MODIFIES: command
    //EFFECTS: Helper method that initializes the command string by reading user input
    private String initializeCommand() {
        String command = input.next();
        command = command.toLowerCase();
        return command;
    }

    //EFFECTS: Helper method that returns the recipe that matches the name of the recipe that the user wants to edit.
    // The recipe returned may be null if no recipe matches the name given.
    private Recipe getRecipeToEdit() {
        System.out.println("Enter the name of the recipe you would like to edit: ");
        String recipeName = input.next();
        return flowerShop.findRecipe(recipeName);
    }

    //EFFECTS: saves the flower shop to the file
    private void saveFlowerShop() {
        try {
            jsonWriter.open();
            jsonWriter.write(flowerShop);
            jsonWriter.close();
            System.out.println("Successfully saved " + flowerShop.getName() + " to " + FlowerShopApp.JSON_STORE);

        } catch (FileNotFoundException e) {
            System.out.println("Error. Unable to save file to: " + FlowerShopApp.JSON_STORE);
        }
    }

    //MODIFIES: this
    //EFFECTS: loads the flower shop from the file
    private void loadFlowerShop() {
        try {
            this.flowerShop = jsonReader.read();
            plantMenu = new PlantMenu(flowerShop);
            recipeMenu = new RecipeMenu(flowerShop);
            orderMenu = new OrderMenu(flowerShop);
            System.out.println("Successfully loaded " + flowerShop.getName() + " from " + FlowerShopApp.JSON_STORE);
        } catch (IOException e) {
            System.out.println("Error. Unable to read file from: " + FlowerShopApp.JSON_STORE);
        }
    }
}
