package ui;

import model.Event;
import model.EventLog;
import model.FlowerShop;
import persistence.JsonReader;
import persistence.JsonWriter;
import ui.tabs.HomeTab;
import ui.tabs.OrdersTab;
import ui.tabs.InventoryTab;
import ui.tabs.RecipesTab;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

// Graphic Interface for the FlowerShop Application.

// Credits: The structure for this GUI was modeled after: https://github.students.cs.ubc.ca/CPSC210/AlarmSystem
// In all UI classes, Oracle's Swing library documentation was used:
// https://docs.oracle.com/javase/8/docs/api/javax/swing/package-summary.html
// Tutorials for structuring the visual component and setting up the paintComponent method come from:
// https://stackoverflow.com/questions/39763573/how-to-paint-on-jframe
// Information about implementing WindowListeners:
// https://stackoverflow.com/questions/32051657/how-to-perform-action-after-jframe-is-closed
// https://docs.oracle.com/javase/7/docs/api/java/awt/event/WindowListener.html
// EVENT PRINTING: https://github.students.cs.ubc.ca/CPSC210/AlarmSystem.git

public class FlowerShopAppUI extends JFrame {

    public static final int HOME_TAB_INDEX = 0;
    public static final int INVENTORY_TAB_INDEX = 1;
    public static final int RECIPE_TAB_INDEX = 2;
    public static final int ORDER_TAB_INDEX = 3;
    public static final Color BACKGROUND_COLOR = new Color(156, 175, 136);
    public static final int WIDTH = 900;
    public static final int HEIGHT = 600;

    private final JTabbedPane topBar;
    private FlowerShop flowerShop;

    private JPanel homeTab;
    private JPanel inventoryTab;
    private JPanel recipeTab;
    private JPanel orderTab;

    public static void main(String[] args) {
        FlowerShopAppUI flowerShopApp = new FlowerShopAppUI();
    }

    //MODIFIES: this
    //EFFECTS: Loads the main frame for the FlowerShop GUI
    private FlowerShopAppUI() {
        super("Sprout Stock");
        setSize(WIDTH, HEIGHT);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                EventLog el = EventLog.getInstance();
                for (Event next: el) {
                    System.out.println(next.toString() + "\n");
                }
            }
        });

        flowerShop = new FlowerShop("Sprout Stock");

        topBar = new JTabbedPane();
        topBar.setTabPlacement(JTabbedPane.TOP);

        runSplash();

        loadTabs();
        add(topBar);
    }



    //MODIFIES: this
    //EFFECTS: Runs the logo splash screen that appears during app startup
    private void runSplash() {

        final BufferedImage sproutStockLogo;
        try {
            sproutStockLogo = ImageIO.read(new File("./data/images/sproutStockLogo.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        JPanel logoPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(sproutStockLogo, 0, 0, this);
            }
        };

        add(logoPanel);
        setVisible(true);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        remove(logoPanel);
    }

    //MODIFIES: this
    //EFFECTS: adds the home, plant, recipe, and order tab to this GUI
    private void loadTabs() {
        homeTab = new HomeTab(this);
        inventoryTab = new InventoryTab(this);
        recipeTab = new RecipesTab(this);
        orderTab = new OrdersTab(this);

        topBar.add(homeTab, HOME_TAB_INDEX);
        topBar.setTitleAt(HOME_TAB_INDEX, "Home");
        homeTab.setBackground(BACKGROUND_COLOR);

        topBar.add(inventoryTab, INVENTORY_TAB_INDEX);
        topBar.setTitleAt(INVENTORY_TAB_INDEX, "Inventory");
        inventoryTab.setBackground(BACKGROUND_COLOR);

        topBar.add(recipeTab, RECIPE_TAB_INDEX);
        topBar.setTitleAt(RECIPE_TAB_INDEX, "Recipes");
        recipeTab.setBackground(BACKGROUND_COLOR);

        topBar.add(orderTab, ORDER_TAB_INDEX);
        topBar.setTitleAt(ORDER_TAB_INDEX, "Orders");
        orderTab.setBackground(BACKGROUND_COLOR);
    }

    public FlowerShop getFlowerShop() {
        return flowerShop;
    }

    public JPanel getInventoryTab() {
        return inventoryTab;
    }

    public JPanel getRecipeTab() {
        return recipeTab;
    }

    public JPanel getOrderTab() {
        return orderTab;
    }

    public JPanel getHomeTab() {
        return homeTab;
    }

    public void setFlowerShop(FlowerShop flowerShop) {
        this.flowerShop = flowerShop;
    }



}
