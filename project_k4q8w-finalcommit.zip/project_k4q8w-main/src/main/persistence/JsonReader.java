package persistence;

import model.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

// Represents a reader that reads the Flower Shop from the source file
// CREDIT: The code and structure in the class was learned and replicated from the JsonSerializationDemo file from
//         CPSC210 EDx: https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo

public class JsonReader {

    private final String source;

    //EFFECTS: Creates a new reader to read from the given source file
    public JsonReader(String source) {
        this.source = source;
    }

    //EFFECTS: reads the FlowerShop from file and returns it
    // throws IOException if an error occurs reading the data.
    public FlowerShop read() throws IOException {
        String jsonData = readFile(source);
        JSONObject jsonObject = new JSONObject(jsonData);
        return parseFlowerShop(jsonObject);
    }

    //EFFECTS: reads the source file as a string and returns it
    private String readFile(String source) throws IOException {
        StringBuilder jsonContent = new StringBuilder();

        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> jsonContent.append(s));
        }
        return jsonContent.toString();
    }

    //MODIFIES: fs
    //EFFECTS: parses a FlowerShop from the JSONObject and returns it
    private FlowerShop parseFlowerShop(JSONObject jsonObject) {
        EventLog.getInstance().logEvent(new Event("Loaded the FlowerShop"));
        String name = jsonObject.getString("name");
        List<Plant> inventory = getInventory(jsonObject);
        List<Recipe> recipes = getRecipes(jsonObject);
        List<Order> current = getOrders(jsonObject, "current orders");
        List<Order> complete =  getOrders(jsonObject, "completed orders");
        FlowerShop fs = new FlowerShop(name, inventory, recipes, complete, current);
        return fs;
    }

    //MODIFIES: fs
    //EFFECTS: Parses the plants from JSON object and adds them to the flower shop inventory
    private List<Plant> getInventory(JSONObject jsonObject) {
        JSONArray jsonArray = jsonObject.getJSONArray("plant inventory");
        List<Plant> plants = new ArrayList<>();
        for (Object json : jsonArray) {
            JSONObject nextPlant = (JSONObject) json;
            Plant plant = parsePlant(nextPlant);
            plants.add(plant);
        }
        return plants;
    }

    //EFFECTS: Parses the plant from the JSONObject and returns it.
    private Plant parsePlant(JSONObject jsonObject) {
        String name = jsonObject.getString("name");
        double stemPrice = jsonObject.getDouble("Stem Price");
        int stemsInStock = jsonObject.getInt("Stems in Stock");
        return new Plant(name, stemPrice, stemsInStock);
    }

    //MODIFIES: fs
    //EFFECTS: parses the recipes in the json object and adds them to the flower shop
    private List<Recipe> getRecipes(JSONObject jsonObject) {
        JSONArray jsonArray = jsonObject.getJSONArray("available recipes");
        List<Recipe> recipes = new ArrayList<>();
        for (Object json: jsonArray) {
            JSONObject nextRecipe = (JSONObject) json;
            Recipe recipe = parseRecipe(nextRecipe);
            recipes.add(recipe);
        }
        return recipes;
    }


    //EFFECTS: parses the recipe from json object and returns it
    private Recipe parseRecipe(JSONObject jsonObject) {
        String name = jsonObject.getString("name");
        double materials = jsonObject.getDouble("material cost");
        Recipe recipe = new Recipe(name);
        recipe.setMaterialCost(materials);

        List<Plant> plantsNeeded = new ArrayList<>();
        JSONArray jsonPlantArray = jsonObject.getJSONArray("plants needed");
        for (Object json: jsonPlantArray) {
            JSONObject nextPlant = (JSONObject) json;
            plantsNeeded.add(parsePlant(nextPlant));
        }

        List<Integer> stemsNeeded = new ArrayList<>();
        JSONArray jsonStemArray = jsonObject.getJSONArray("stems needed");
        for (int i = 0; i < jsonStemArray.length(); i++) {
            stemsNeeded.add(jsonStemArray.getInt(i));
        }

        for (int i = 0; i < plantsNeeded.size(); i++) {
            recipe.addPlant(plantsNeeded.get(i), stemsNeeded.get(i));
        }
        return recipe;
    }

    //MODIFIES: fs
    //EFFECTS: Parses orders from the json object and adds them to the appropriate list in the flower shop
    private List<Order> getOrders(JSONObject jsonObject, String listName) {
        JSONArray jsonArray = jsonObject.getJSONArray(listName);
        List<Order> orders = new ArrayList<>();
        for (Object json: jsonArray) {
            JSONObject nextOrder = (JSONObject) json;
            Order order = parseOrder(nextOrder);
            orders.add(order);
        }
        return orders;
    }

    //MODIFIES: fs
    //EFFECTS: Parses the order from the json object and adds it to the appropriate list in the flower shop
    private Order parseOrder(JSONObject jsonObject) {

        List<Recipe> orderRecipes = new ArrayList<>();
        JSONArray orderRecipesJson = jsonObject.getJSONArray("Recipes");
        for (Object json: orderRecipesJson) {
            JSONObject nextRecipe = (JSONObject) json;
            orderRecipes.add(parseRecipe(nextRecipe));
        }

        Order newOrder = new Order(orderRecipes);
        newOrder.setOrderStatus(jsonObject.getString("Status"));
        newOrder.setOrderNumber(jsonObject.getInt("Order Number"));
        return newOrder;
    }











}
