package persistence;

import model.Event;
import model.EventLog;
import model.FlowerShop;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

// Represents a writer that writes JSON representation of Flower Shop to file
// CREDIT: The code and structure in the class was learned and replicated from the JsonSerializationDemo file from
//         CPSC210 EDx: https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo

public class JsonWriter {

    private static final int TAB = 4;
    private PrintWriter writer;
    private String destination;

    //EFFECTS: constructs a new writer to write to the destination file
    public JsonWriter(String destination) {
        this.destination = destination;
    }

    //MODIFIES: this
    //EFFECTS: Opens the writer;
    // throws FileNotFound exception if destination file cannot be opened for writing
    public void open() throws FileNotFoundException {
        writer = new PrintWriter((destination));
    }

    //MODIFIES: this
    //EFFECTS: closes the writer
    public void close() {
        writer.close();
    }

    //MODIFIES: this
    //EFFECTS: writes JSON representation of the flower shop to file
    public void write(FlowerShop fs) {
        JSONObject json = fs.toJson();
        saveToFile(json.toString(TAB));
    }

    //MODIFIES: this
    //EFFECTS: writes the string to file
    private void saveToFile(String json) {
        writer.print(json);
        EventLog.getInstance().logEvent(new Event("Saved the FlowerShop"));
    }






}
