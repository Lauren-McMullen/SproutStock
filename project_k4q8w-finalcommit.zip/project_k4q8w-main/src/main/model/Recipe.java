package model;



import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Writable;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

// Represents a floral design recipe, including a name, a price,
// the plants needed (and the number of stems of each plant type in a list with corresponding indexes),
// and the cost of materials and labour.
// CREDITS: In this Class, https://www.baeldung.com/java-round-decimal-number was used as a resource for a way
// to round doubles

public class Recipe implements Writable {


    static final double LABOUR_COST = 1.30; //Cost of labour applied to each recipe cost

    private String name;
    private double materialCost;
    private List<Plant> plantsNeeded;
    private List<Integer> stemCounts;

    // EFFECTS: Creates a blank recipe with only a name (no flowers or costs included)
    public Recipe(String name) {
        this.name = name;
        plantsNeeded = new ArrayList<>();
        stemCounts = new ArrayList<>();
        materialCost = 0.0;
    }

    // REQUIRES: number of stems > 0
    // MODIFIES: this
    // EFFECTS: Adds the number of stems of the new plant to this recipe. More than one plant in the recipe cannot
    // share the same name (the stem count is instead added to the existing plant with the given name).
    public void addPlant(Plant newPlant, int count) {
        String plantName = newPlant.getName();
        if (getPlantNamesInRecipe().contains(plantName)) {
            int plantIndex = plantsNeeded.indexOf(newPlant);
            int currentCount = stemCounts.get(plantIndex);
            stemCounts.set(plantIndex, currentCount + count);
        } else {
            plantsNeeded.add(newPlant);
            stemCounts.add(count);
        }
    }

    //REQUIRES: the plant already exists in the recipe
    //MODIFIES: this
    //EFFECTS: The plants and stem count are removed from this recipe.
    public void removePlant(Plant plant) {
        for (Plant next: plantsNeeded) {
            if (next.getName().equals(plant.getName())) {
                stemCounts.remove(plantsNeeded.indexOf(next));
                plantsNeeded.remove(next);
                return;
            }
        }
    }

    // REQUIRES: At least one plant has been added to the recipe
    // EFFECTS: Returns the price to make the recipe with the stems cost,
    //          material costs, and labour cost factored in.
    public double calculatePrice() {
        double price = 0.0;
        for (Plant nextPlant: plantsNeeded) {
            double stemPrice = nextPlant.getPerStemPrice();
            int stemsNeeded = getStemsNeededForPlant(nextPlant);
            price += stemPrice * stemsNeeded;
        }
        price = (price + materialCost) * LABOUR_COST;
        return price;
    }


    //MODIFIES: All Plants in this recipe
    //EFFECTS: If there are enough stems of plants in stock of each plant type in recipe,
    //         the corresponding number of stems are removed from stock and the method returns true.
    //         Otherwise, return false to signal that recipe could not be made.
    public boolean make() {
        if (checkEnoughStocksForRecipe()) {
            for (Plant nextPlant: plantsNeeded) {
                int stemsNeeded = getStemsNeededForPlant(nextPlant);
                nextPlant.sellStems(stemsNeeded);
            }
            return true;
        } else {
            return false;
        }
    }

    //EFFECTS: Returns true if there are enough stems in stock to make this recipe. Else,
    //         returns false.
    public boolean checkEnoughStocksForRecipe() {
        boolean result = true;
        for (Plant nextPlant: plantsNeeded) {
            int stemsNeeded = getStemsNeededForPlant(nextPlant);
            if (stemsNeeded > nextPlant.getStemStock()) {
                result = false;
            }
        }
        return result;
    }

    //EFFECTS: Returns a summary list of all the flowers and the stems counts in this recipe.
    public String getRecipeSummary() {
        DecimalFormat df = new DecimalFormat("#####.##");
        String flowersInRecipe = "";
        for (Plant nextPlant: plantsNeeded) {
            int stemsNeeded = getStemsNeededForPlant(nextPlant);
            flowersInRecipe = (flowersInRecipe + " - " + nextPlant.getName() + ": " + stemsNeeded);
        }
        return (getName() + "\nTotal cost: $" + df.format(calculatePrice()) + "\n" + flowersInRecipe + "\n");
    }

    //EFFECTS: Returns a list of all the plant names in the recipe
    public List<String> getPlantNamesInRecipe() {
        List<String> plantNames = new ArrayList<>();
        for (Plant nextPlant: plantsNeeded) {
            plantNames.add(nextPlant.getName());
        }
        return plantNames;
    }

    //REQUIRES: The plant name given exists for a plant in this recipe's list of plants.
    //EFFECTS: Returns a plant matching the name
    public Plant findPlant(String plantName) {
        for (Plant nextPlant: plantsNeeded) {
            String nextName = nextPlant.getName();
            if (nextName.equals(plantName)) {
                return nextPlant;
            }
        }
        return null;
    }

    //EFFECTS: Returns the number of stems needed for plant in this recipe.
    public int getStemsNeededForPlant(Plant plant) {
        int plantIndex = plantsNeeded.indexOf(plant);
        return stemCounts.get(plantIndex);
    }


    //REQUIRES: At least one plant has been added to the recipe
    //EFFECTS: Sums the total number of plants stems needed to make this recipe
    public int getTotalStemCount() {
        int stemCount = 0;
        for (int nextStemCount: stemCounts) {
            stemCount += nextStemCount;
        }
        return stemCount;
    }


    public void setMaterialCost(double cost) {
        this.materialCost = cost;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getStemCounts() {
        return stemCounts;
    }

    public List<Plant> getPlantsNeeded() {
        return plantsNeeded;
    }

    public int getPlantTypeCount() {
        return this.plantsNeeded.size();
    }

    public double getLabourCost() {
        return LABOUR_COST;
    }

    public double getMaterialCost() {
        return materialCost;
    }


    @Override
    //EFFECTS: returns this as a JSON object
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("name", name);
        json.put("material cost", materialCost);
        json.put("plants needed", plantsToJson());
        json.put("stems needed", stemsToJson());

        return json;
    }

    //EFFECTS: creates and returns a json array of the plants needed for this recipe
    private JSONArray plantsToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Plant p: plantsNeeded) {
            jsonArray.put(p.toJson());
        }
        return jsonArray;
    }

    //EFFECTS: Creates and returns a json array of the stems needed for each plant listed in this recipe
    private JSONArray stemsToJson() {
        JSONArray jsonArray = new JSONArray();

        for (int i: stemCounts) {
            jsonArray.put(i);
        }
        return jsonArray;
    }




}
