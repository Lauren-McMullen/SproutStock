package model;

import org.json.JSONObject;
import persistence.Writable;

// Represents a plant stocked in a flower shop with a name, a price per stem,
// and the number of stems in stock

public class Plant implements Writable {

    private final String name;
    private double pricePerStem;
    private int stemsInStock;

    // REQUIRES: price > 0, number in stock >= 0
    // EFFECTS: Creates a new place with a name, current price, and the
    //          current number in stock.
    public Plant(String name, double price, int numInStock) {
        this.name = name;
        this.pricePerStem = price;
        this.stemsInStock = numInStock;
    }

    //REQUIRES: price is > 0
    //MODIFIES: this
    //EFFECT: sets the current price of this plant to new price
    public void changePrice(double price) {
        EventLog.getInstance().logEvent(new Event("Changed the price of: " + name + " to " + price));
        this.pricePerStem = price;

    }

    // MODIFIES: this
    // EFFECT: Add the new stock to this plant's stems in stock
    public void addStock(int newStock) {
        EventLog.getInstance().logEvent(new Event("Added " + newStock + " new stems of: " + name));
        this.stemsInStock += newStock;

    }

    // MODIFIES: this
    // EFFECT: If there are enough stems in stock, remove the requested
    //         number of stems from the inventory and return true.
    //         Else, return false and does not change the stock.
    public boolean sellStems(int stemNum) {
        if (this.stemsInStock >= stemNum) {
            this.stemsInStock -= stemNum;
            EventLog.getInstance().logEvent(new Event("Sold " + stemNum + " stems of: " + name));
            return true;
        }
        return false;
    }

    //EFFECT: returns a string summary of the plant's name,  stems in stock and price.
    public String getPlantSummary() {
        return (name + ": " + stemsInStock + " - $" + pricePerStem + " ea.");
    }

    public int getStemStock() {
        return this.stemsInStock;
    }

    public String getName() {
        return this.name;
    }

    public double getPerStemPrice() {
        return this.pricePerStem;
    }



    @Override
    //EFFECTS: returns this as a JSON object
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("name", name);
        json.put("Stem Price", pricePerStem);
        json.put("Stems in Stock", stemsInStock);
        return json;
    }
}
