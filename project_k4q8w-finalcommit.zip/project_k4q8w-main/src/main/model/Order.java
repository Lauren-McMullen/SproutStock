package model;

import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Writable;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

// Represents a customer order with an order number, one or more recipes in the order,
// and a completion status
// CREDITS: In this Class, https://www.baeldung.com/java-round-decimal-number was used as a resource for a way
// to round doubles

public class Order implements Writable {

    private static int maxAllOrderNumber = 0;

    private int orderNumber;
    private String status;
    private final List<Recipe> orderRecipes;



    //REQUIRES: Order recipe list must have at least one recipe
    //EFFECT: Creates a new order with a list of recipes in the order, an order number, and
    //        the order status initialized as "Not Complete"
    public Order(List<Recipe> orderRecipes) {
        this.orderRecipes = new ArrayList<>(orderRecipes);
        this.status = "Not Complete";
        maxAllOrderNumber++;
        this.orderNumber = maxAllOrderNumber;
    }

    //EFFECT: Returns the total price for all recipes in this order
    public double calculatePrice() {
        double totalPrice = 0;
        for (Recipe nextRecipe: orderRecipes) {
            totalPrice += nextRecipe.calculatePrice();
        }
        return totalPrice;
    }


    //EFFECTS: Returns true if there are enough stems in stock to fulfill this order. Else,
    //         returns false.
    public boolean isEnoughStockForOrder() {
        for (Recipe nextRecipe: orderRecipes) {
            if (!nextRecipe.checkEnoughStocksForRecipe()) {
                return false;
            }
        }
        return true;
    }


    //REQUIRES: this order is "not complete"
    //MODIFIES: this
    //EFFECTS: If there is enough stock, calls make() for every recipe listed in this order,
    // sets this order's status to "Complete", and returns true. Else, returns false.
    public boolean makeOrder() {
        if (isEnoughStockForOrder()) {
            for (Recipe nextRecipe: orderRecipes) {
                nextRecipe.make();
            }
            setOrderStatus("Complete");
            return true;
        } else {
            return false;
        }
    }

    //EFFECTS: returns a string with the order number, the recipes in the order, the total price, and the status.
    public String orderSummary() {
        DecimalFormat df = new DecimalFormat("#####.##");
        String recipeList = "";
        for (Recipe nextRecipe: orderRecipes) {
            recipeList = (recipeList + "-" + nextRecipe.getName() + "\n");
        }
        return ("Order #" + getOrderNumber() + ":\n" + recipeList + "\nOrder total: $" + df.format(calculatePrice())
                + "\nStatus: " + getStatus() + "\n");
    }

    public String getStatus() {
        return status;
    }

    public void setOrderStatus(String status) {
        this.status = status;
    }

    public void setOrderNumber(int num) {
        this.orderNumber = num;
    }

    public List<Recipe> getOrderRecipes() {
        return orderRecipes;
    }

    public int getOrderNumber() {
        return orderNumber;
    }

    public int getMaxAllOrderNumber() {
        return maxAllOrderNumber;
    }


    @Override
    //EFFECTS: returns this as a JSON object
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("Order Number", orderNumber);
        json.put("Status", status);
        json.put("Recipes", recipesToJson());
        return json;
    }

    //EFFECTS: Creates and returns a JSON array for the recipes in this order
    private JSONArray recipesToJson() {
        JSONArray jsonArray = new JSONArray();
        for (Recipe r: orderRecipes) {
            jsonArray.put(r.toJson());
        }
        return jsonArray;
    }


}
