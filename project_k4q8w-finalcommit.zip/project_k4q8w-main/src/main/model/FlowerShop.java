package model;



import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Writable;

import java.util.ArrayList;
import java.util.List;

//Represents a flower shop with a name, a list of Plants that are in stock,
// a suite of recipes, a list of current orders, and a list of completed orders.

public class FlowerShop implements Writable {

    private final String name;
    private List<Plant> plantInventory;
    private List<Recipe> availableRecipes;
    private List<Order> currentOrders;
    private List<Order> completedOrders;

    //EFFECTS: Creates a flower shop with the given name, an empty list of current orders,
    // an empty list of recipes, an empty list of the store's plant inventory.
    public FlowerShop(String name) {
        this.name = name;
        this.availableRecipes = new ArrayList<>();
        this.currentOrders = new ArrayList<>();
        this.completedOrders = new ArrayList<>();
        this.plantInventory = new ArrayList<>();
    }

    //EFFECTS: Creates a flower shop with the given name, a list of current orders,
    // a list of recipes, and a list of the store's plant inventory.
    public FlowerShop(String name, List<Plant> plants, List<Recipe> recipes,
                      List<Order> completed, List<Order> current) {
        this.name = name;
        this.availableRecipes = new ArrayList<>(recipes);
        this.currentOrders = new ArrayList<>(current);
        this.completedOrders = new ArrayList<>(completed);
        this.plantInventory = new ArrayList<>(plants);
    }


    //MODIFIES: this
    //EFFECTS: If a plant with this name is not yet in the inventory, adds the plant to this store's inventory list
    // and returns true.
    // Attempting to add a duplicate plant returns false.
    public boolean addInventory(Plant plant) {
        List<String> plantNames = new ArrayList<>();
        for (Plant nextPlant: plantInventory) {
            plantNames.add(nextPlant.getName());
        }
        if (plantNames.contains(plant.getName())) {
            return false;
        }
        plantInventory.add(plant);
        EventLog.getInstance().logEvent(new Event("Plant added to the flower shop: " + plant.getName()));

        return true;
    }


    //MODIFIES: this
    //EFFECTS: If the plant exists in the inventory, removes the plant to this store's inventory list and returns true.
    // Else, returns false.
    public boolean removeInventory(Plant plant) {
        if (plantInventory.contains(plant)) {
            plantInventory.remove(plant);
            EventLog.getInstance().logEvent(new Event("Removed plant from the flower shop: " + plant.getName()));
            return true;
        }
        return false;
    }

    //MODIFIES: this
    //EFFECTS: Adds the recipe to the current suite available at this flower shop
    public void addRecipe(Recipe recipe) {
        EventLog.getInstance().logEvent(new Event("Added new recipe to the flower shop: " + recipe.getName()));
        availableRecipes.add(recipe);
    }

    //REQUIRES: recipe already exists in this flower shop
    //MODIFIES: this
    //EFFECTS: Removes the recipe from the current suite available at this flower shop
    public void removeRecipe(Recipe recipe) {
        EventLog.getInstance().logEvent(new Event("Removed recipe to the flower shop: " + recipe.getName()));
        availableRecipes.remove(recipe);
    }

    //EFFECTS: Returns a list of recipes that have the same name that exist in the suite of recipes in this flower shop,
    //         otherwise returns and empty list if no recipes were not found.
    public List<Recipe> searchRecipesByName(String name) {
        List<Recipe> matchingRecipes = new ArrayList<>();
        for (Recipe nextRecipe: availableRecipes) {
            if (nextRecipe.getName().equals(name)) {
                matchingRecipes.add(nextRecipe);
            }
        }
        return matchingRecipes;
    }

    //EFFECTS: Returns a list of all the recipes in this flower shop's suite that use the plant
    public List<Recipe> searchRecipesByPlant(Plant plant) {
        List<Recipe> matchingRecipes = new ArrayList<>();
        String plantName = plant.getName();

        for (Recipe nextRecipe: availableRecipes) {
            List<String> allPlants = nextRecipe.getPlantNamesInRecipe();
            if (allPlants.contains(plantName)) {
                matchingRecipes.add(nextRecipe);
            }
        }
        return matchingRecipes;
    }

    //EFFECTS: Returns the first recipe in the available recipe list that matches the given name.
    public Recipe findRecipe(String recipeName) {
        for (Recipe next: availableRecipes) {
            if (next.getName().equals(recipeName)) {
                return next;
            }
        }
        return null;
    }

    //REQUIRES: the order being added has status "Not Complete"
    //MODIFIES: this
    //EFFECTS: Adds the order this flower shop's current orders
    public void addCurrentOrder(Order order) {
        currentOrders.add(order);
    }

    //REQUIRES: the order being added has status "Complete"
    //MODIFIES: this
    //EFFECTS: Adds the order this flower shop's completed orders
    public void addCompletedOrder(Order order) {
        order.setOrderStatus("Complete");
        completedOrders.add(order);
    }

    //REQUIRES: Can only be called in cases where oder.makeOrder returns true.
    //MODIFIES: this, order
    //EFFECTS: Makes the order, removes it from the current orders, and add it to the completed orders
    public void completeOrder(Order order) {
        order.makeOrder();
        this.currentOrders.remove(order);
        this.completedOrders.add(order);
    }


    //EFFECTS: Returns the order matching the order number if it exists, else returns null.
    public Order findOrder(int orderNumber) {
        List<Order> allOrders = new ArrayList<>();
        allOrders.addAll(getCurrentOrders());
        allOrders.addAll(getCompletedOrders());
        for (Order nextOrder: allOrders) {
            if (nextOrder.getOrderNumber() == orderNumber) {
                return nextOrder;
            }

        }
        return null;
    }


    //EFFECTS: Returns the plant matching the name if it exists in the inventory, else returns null.
    public Plant findPlant(String plantName) {
        for (Plant nextPlant: plantInventory) {
            if (nextPlant.getName().equals(plantName)) {
                return nextPlant;
            }
        }
        return null;
    }


    //EFFECTS: Returns all the order numbers for current orders.
    public List<Integer> getCurrentOrderNumbers() {
        List<Integer> allCurrentOrderNumbers = new ArrayList<>();
        for (Order nextCurrentOrder: currentOrders) {
            allCurrentOrderNumbers.add(nextCurrentOrder.getOrderNumber());
        }
        return allCurrentOrderNumbers;
    }


    //EFFECTS: Returns all the order numbers for completed orders.
    public List<Integer> getCompletedOrderNumbers() {
        List<Integer> allCompletedOrderNumbers = new ArrayList<>();
        for (Order nextCurrentOrder: completedOrders) {
            allCompletedOrderNumbers.add(nextCurrentOrder.getOrderNumber());
        }
        return allCompletedOrderNumbers;
    }


    //EFFECTS: Returns a summary of all the plants in the store with their current stem counts.
    public List<String> inventorySummary() {
        List<String> inventorySummary = new ArrayList<>();
        for (Plant nextPlant: plantInventory) {
            inventorySummary.add(nextPlant.getPlantSummary() + "\n");
        }
        return inventorySummary;
    }

    //EFFECTS: Returns a String summary of all the orders in the given list
    public List<String> ordersSummary(List<Order> ordersList) {
        List<String> orderSummaryList = new ArrayList<>();
        for (Order nextOrder: ordersList) {
            orderSummaryList.add(nextOrder.orderSummary());
        }
        return orderSummaryList;
    }


    //EFFECTS: Returns a list of summaries for the recipes in the list.
    public List<String> recipesSummary(List<Recipe> recipes) {
        List<String> recipeSummaryList = new ArrayList<>();
        for (Recipe nextRecipe: recipes) {
            String summary = nextRecipe.getRecipeSummary();
            recipeSummaryList.add(summary);
        }
        return recipeSummaryList;
    }


    public List<Order> getCurrentOrders() {
        return currentOrders;
    }

    public List<Order> getCompletedOrders() {
        return completedOrders;
    }

    public List<Recipe> getAllRecipes() {
        return availableRecipes;
    }

    public List<Plant> getInventory() {
        return plantInventory;
    }

    public String getName() {
        return name;
    }


    @Override
    //EFFECTS: returns this as a JSON object
    public JSONObject toJson() {
        JSONObject json = new JSONObject();

        json.put("name", name);
        json.put("plant inventory", plantsToJson());
        json.put("available recipes", recipesToJson());
        json.put("current orders", ordersToJson(currentOrders));
        json.put("completed orders", ordersToJson(completedOrders));

        return json;
    }

    //EFFECTS: Returns the list of plants in this inventory as a json array
    private JSONArray plantsToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Plant p: plantInventory) {
            jsonArray.put(p.toJson());
        }
        return jsonArray;
    }

    //EFFECTS: Returns the list of recipes in this flower shop as a json array
    private JSONArray recipesToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Recipe r: availableRecipes) {
            jsonArray.put(r.toJson());
        }
        return jsonArray;
    }


    //EFFECTS: Returns the given list of orders as a json array
    private JSONArray ordersToJson(List<Order> orders) {
        JSONArray jsonArray = new JSONArray();

        for (Order o: orders) {
            jsonArray.put(o.toJson());
        }
        return jsonArray;
    }










}
