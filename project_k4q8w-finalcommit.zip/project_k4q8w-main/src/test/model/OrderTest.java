package model;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class OrderTest {

    Order testOrder1;
    Order testOrder2;
    Recipe testRecipe1;
    Recipe testRecipe2;
    Plant testPlantRose;
    Plant testPlantDaisy;

    @BeforeEach
    void runBefore() {
        testPlantRose = new Plant("Rose", 4.95, 40);
        testPlantDaisy = new Plant("Gerbera Daisy", 3.95, 20);

        testRecipe1 = new Recipe("Summer Day Bouquet");
        testRecipe1.addPlant(testPlantRose, 6);
        testRecipe1.addPlant(testPlantDaisy, 10);

        testRecipe2 = new Recipe("Wonderful Wish Vase");
        testRecipe2.addPlant(testPlantRose, 24);
        testRecipe2.addPlant(testPlantDaisy, 5);

        List<Recipe> testRecipeList1 = new ArrayList<>();
        testRecipeList1.add(testRecipe1);
        testOrder1 = new Order(testRecipeList1);

        List<Recipe> testRecipeList2 = new ArrayList<>();
        testRecipeList2.add(testRecipe1);
        testRecipeList2.add(testRecipe2);
        testOrder2 = new Order(testRecipeList2);
    }

    @Test
    void testConstructor() {
        assertEquals("Not Complete", testOrder2.getStatus());
        assertEquals(testOrder2.getMaxAllOrderNumber(), testOrder2.getOrderNumber());
        assertEquals(2, testOrder2.getOrderRecipes().size());
        assertEquals(testRecipe1, testOrder2.getOrderRecipes().get(0));
        assertEquals(testRecipe2, testOrder2.getOrderRecipes().get(1));
    }

   @Test
    void testCalculateOrderPriceOneRecipe() {
        assertEquals(testRecipe1.calculatePrice(), testOrder1.calculatePrice());
   }

    @Test
    void testCalculateOrderPriceMultipleRecipe() {
        assertEquals(testRecipe1.calculatePrice() + testRecipe2.calculatePrice(), testOrder2.calculatePrice());
    }

    @Test
    void testEnoughStockForOrderExactlyTrue() {
        testRecipe1.addPlant(testPlantRose, 10);
        testRecipe2.addPlant(testPlantDaisy, 5);
        assertTrue(testOrder2.isEnoughStockForOrder());
    }

    @Test
    void testEnoughStockForOrderTrue() {
        assertTrue(testOrder2.isEnoughStockForOrder());
    }

    @Test
    void testEnoughStockForOrderFalse() {
        testRecipe1.addPlant(testPlantRose, 40);
        assertFalse(testOrder1.isEnoughStockForOrder());
    }

    @Test
    void testMakeOrderEnoughStock() {
        assertTrue(testOrder2.makeOrder());
        assertEquals("Complete", testOrder2.getStatus());
    }

    @Test
    void testMakeOrderNotEnoughStock() {
        testRecipe1.addPlant(testPlantRose, 40);
        assertFalse(testOrder2.makeOrder());
        assertEquals("Not Complete", testOrder2.getStatus());
    }

    @Test
    void testOrderSummaryOneRecipe() {
        DecimalFormat df = new DecimalFormat("###.##");
        String expectedSummary = ("Order #" + testOrder1.getOrderNumber() + ":\n" + "-Summer Day Bouquet\n"
                + "\nOrder total: $" + df.format(testOrder1.calculatePrice()) + "\nStatus: Not Complete" + "\n");
        assertEquals(expectedSummary, testOrder1.orderSummary());
    }

    @Test
    void testOrderSummaryMultipleRecipes() {
        DecimalFormat df = new DecimalFormat("###.##");
        String expectedSummary = ("Order #" + testOrder2.getOrderNumber() + ":\n"
                + "-Summer Day Bouquet\n-Wonderful Wish Vase\n" + "\nOrder total: $"
                + df.format(testOrder2.calculatePrice()) + "\nStatus: Not Complete" + "\n");

        assertEquals(expectedSummary, testOrder2.orderSummary());
    }







}
