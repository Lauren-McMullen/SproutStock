package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class FlowerShopTest {

    Recipe testRecipe1;
    Recipe testRecipe2;
    Recipe testRecipe3;
    Recipe testRecipe4;
    Plant testPlantRose;
    Plant testPlantDaisy;
    Plant testPlantLeatherLeaf;
    Plant testPlantCallaLily;
    Order testOrder1;
    Order testOrder2;
    Order testOrder3;
    FlowerShop testFlowerShop;

    @BeforeEach
    void runBefore() {
        initializeRecipes();

        List<Recipe> testRecipeList1 = new ArrayList<>();
        testRecipeList1.add(testRecipe1);
        testOrder1 = new Order(testRecipeList1);

        List<Recipe> testRecipeList2 = new ArrayList<>();
        testRecipeList2.add(testRecipe1);
        testRecipeList2.add(testRecipe2);
        testOrder2 = new Order(testRecipeList2);

        List<Recipe> testRecipeList3 = new ArrayList<>();
        testRecipeList2.add(testRecipe3);
        testRecipeList2.add(testRecipe4);
        testOrder3 = new Order(testRecipeList3);

        testFlowerShop = new FlowerShop("Test Shop");
    }

    @Test
    void testConstructor() {
        assertEquals("Test Shop", testFlowerShop.getName());
        assertEquals(0, testFlowerShop.getCurrentOrders().size());
        assertEquals(0, testFlowerShop.getCompletedOrders().size());
        assertEquals(0, testFlowerShop.getAllRecipes().size());
        assertEquals(0, testFlowerShop.getInventory().size());
    }

    @Test
    void testAddOneNewInventory() {
        assertTrue(testFlowerShop.addInventory(testPlantRose));
        List<Plant> result = testFlowerShop.getInventory();
        assertEquals(1, result.size());
        assertEquals(testPlantRose, result.get(0));
    }

    @Test
    void testAddMultipleSameInventory() {
        assertTrue(testFlowerShop.addInventory(testPlantRose));
        assertFalse(testFlowerShop.addInventory(testPlantRose));
        List<Plant> result = testFlowerShop.getInventory();
        assertEquals(1, result.size());
        assertEquals(testPlantRose, result.get(0));
    }

    @Test
    void testAddMultipleDifferentInventory() {
        assertTrue(testFlowerShop.addInventory(testPlantRose));
        assertTrue(testFlowerShop.addInventory(testPlantCallaLily));
        List<Plant> result = testFlowerShop.getInventory();
        assertEquals(2, result.size());
        assertEquals(testPlantRose, result.get(0));
        assertEquals(testPlantCallaLily, result.get(1));
    }

    @Test
    void testRemoveFromEmptyInventory() {
        assertFalse(testFlowerShop.removeInventory(testPlantCallaLily));
        List<Plant> result = testFlowerShop.getInventory();
        assertEquals(0, result.size());
    }

    @Test
    void testRemoveOneFromInventory() {
        testFlowerShop.addInventory(testPlantRose);
        assertTrue(testFlowerShop.removeInventory(testPlantRose));
        List<Plant> result = testFlowerShop.getInventory();
        assertEquals(0, result.size());
    }

    @Test
    void testRemoveMultipleFromInventory() {
        testFlowerShop.addInventory(testPlantRose);
        testFlowerShop.addInventory(testPlantDaisy);
        assertTrue(testFlowerShop.removeInventory(testPlantRose));
        assertTrue(testFlowerShop.removeInventory(testPlantDaisy));
        List<Plant> result = testFlowerShop.getInventory();
        assertEquals(0, result.size());
    }

    @Test
    void testRemoveFromInventoryNotInInventory() {
        testFlowerShop.addInventory(testPlantRose);
        testFlowerShop.addInventory(testPlantDaisy);
        assertFalse(testFlowerShop.removeInventory(testPlantLeatherLeaf));
        List<Plant> result = testFlowerShop.getInventory();
        assertEquals(2, result.size());
    }

    @Test
    void testInventorySummaryEmpty() {
        assertEquals(0, testFlowerShop.inventorySummary().size());
    }

    @Test
    void testInventorySummaryNotEmpty() {
        testFlowerShop.addInventory(testPlantRose);
        testFlowerShop.addInventory(testPlantDaisy);

       List<String> result = testFlowerShop.inventorySummary();
       assertEquals(2, result.size());
       assertEquals((testPlantRose.getPlantSummary() + "\n"), result.get(0));
       assertEquals((testPlantDaisy.getPlantSummary() + "\n"), result.get(1));
    }

    @Test
    void testAddOneRecipe() {
        testFlowerShop.addRecipe(testRecipe1);
        assertEquals(1, testFlowerShop.getAllRecipes().size());
        assertEquals(testRecipe1, testFlowerShop.getAllRecipes().get(0));
    }

    @Test
    void testAddMultipleRecipes() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        assertEquals(2, testFlowerShop.getAllRecipes().size());
        assertEquals(testRecipe1, testFlowerShop.getAllRecipes().get(0));
        assertEquals(testRecipe2, testFlowerShop.getAllRecipes().get(1));
    }

    @Test
    void testRemoveOneRecipeFromStart() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        testFlowerShop.removeRecipe(testRecipe1);
        assertEquals(1, testFlowerShop.getAllRecipes().size());
        assertEquals(testRecipe2, testFlowerShop.getAllRecipes().get(0));
    }

    @Test
    void testRemoveOneRecipeFromEnd() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        testFlowerShop.removeRecipe(testRecipe2);
        assertEquals(1, testFlowerShop.getAllRecipes().size());
        assertEquals(testRecipe1, testFlowerShop.getAllRecipes().get(0));
    }

    @Test
    void testRemoveManyRecipes() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        testFlowerShop.addRecipe(testRecipe3);
        testFlowerShop.removeRecipe(testRecipe1);
        testFlowerShop.removeRecipe(testRecipe2);
        assertEquals(1, testFlowerShop.getAllRecipes().size());
        assertEquals(testRecipe3, testFlowerShop.getAllRecipes().get(0));
    }

    @Test
    void testRemoveAllRecipes() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        testFlowerShop.removeRecipe(testRecipe1);
        testFlowerShop.removeRecipe(testRecipe2);
        assertEquals(0, testFlowerShop.getAllRecipes().size());
    }

    @Test
    void testSearchByNameDoesNotExist() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        List<Recipe> results = testFlowerShop.searchRecipesByName("Stunning Lilies");
        assertTrue(results.isEmpty());
    }

    @Test
    void testSearchByNameOneExists() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        List<Recipe> results = testFlowerShop.searchRecipesByName("Daisy Daze");
        assertEquals(1, results.size());
        assertEquals(testRecipe2, results.get(0));
    }

    @Test
    void testSearchByNameRepeatsExist() {
        testFlowerShop.addRecipe(testRecipe1);
        Recipe repeatNameRecipe = new Recipe("Summer Day Bouquet");
        testFlowerShop.addRecipe(repeatNameRecipe);

        List<Recipe> results = testFlowerShop.searchRecipesByName("Summer Day Bouquet");
        assertEquals(2, results.size());
        assertEquals(testRecipe1, results.get(0));
        assertEquals(repeatNameRecipe, results.get(1));
    }

    @Test
    void testFindRecipeEmptyMatchingList() {
        assertNull(testFlowerShop.findRecipe("Stunning Lilies"));
    }

    @Test
    void testFindRecipeNoMatchInList() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        assertNull(testFlowerShop.findRecipe("Stunning Lilies"));
    }

    @Test
    void testFindRecipeOneMatchInList() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        assertEquals(testRecipe1, testFlowerShop.findRecipe("Summer Day Bouquet"));
    }

    @Test
    void testFindRecipeMultipleMatchesInList() {
        Recipe matchingNameRecipe = new Recipe("Summer Day Bouquet");
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        testFlowerShop.addRecipe(matchingNameRecipe);
        assertEquals(testRecipe1, testFlowerShop.findRecipe("Summer Day Bouquet"));
    }

    @Test
    void testSearchByPlantNoneExist() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        List<Recipe> results = testFlowerShop.searchRecipesByPlant(testPlantCallaLily);
        assertTrue(results.isEmpty());
    }


    @Test
    void testSearchByPlantOneExists() {
        testFlowerShop.addRecipe(testRecipe3);
        testFlowerShop.addRecipe(testRecipe4);

        List<Recipe> results = testFlowerShop.searchRecipesByPlant(testPlantRose);
        assertEquals(1, results.size());
        assertEquals(testRecipe3, results.get(0));
    }

    @Test
    void testSearchByPlantMultipleExist() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe3);

        List<Recipe> results = testFlowerShop.searchRecipesByPlant(testPlantRose);

        assertEquals(2, results.size());
        assertEquals(testRecipe1, results.get(0));
        assertEquals(testRecipe3, results.get(1));
    }

    @Test
    void testFindPlantDoesNotExist() {
        testFlowerShop.addInventory(testPlantRose);
        testFlowerShop.addInventory(testPlantDaisy);
         assertNull(testFlowerShop.findPlant("Mum"));
    }

    @Test
    void testFindPlantDoesExist() {
        testFlowerShop.addInventory(testPlantRose);
        testFlowerShop.addInventory(testPlantDaisy);
        assertEquals(testPlantRose, testFlowerShop.findPlant("Rose"));
    }


    @Test
    void testAddOneOrder() {
        testFlowerShop.addCurrentOrder(testOrder1);

        List<Order> results = testFlowerShop.getCurrentOrders();

        assertEquals(1, results.size());
        assertEquals(testOrder1, results.get(0));

    }

    @Test
    void testAddMultipleOrders() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);

        List<Order> results = testFlowerShop.getCurrentOrders();

        assertEquals(2, results.size());
        assertEquals(testOrder1, results.get(0));
        assertEquals(testOrder2, results.get(1));

    }

    @Test
    void testCompleteOneOrderFirstOnList() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);

        testFlowerShop.completeOrder(testOrder1);
        List<Order> completedOrders = testFlowerShop.getCompletedOrders();
        List<Order> currentOrders = testFlowerShop.getCurrentOrders();

        assertEquals("Complete", testOrder1.getStatus());
        assertEquals(1, completedOrders.size());
        assertEquals(testOrder1, completedOrders.get(0));
        assertEquals(1, currentOrders.size());
        assertEquals(testOrder2, currentOrders.get(0));

    }

    @Test
    void testCompleteOneOrderLaterInList() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);

        testFlowerShop.completeOrder(testOrder2);
        List<Order> completedOrders = testFlowerShop.getCompletedOrders();
        List<Order> currentOrders = testFlowerShop.getCurrentOrders();

        assertEquals("Complete", testOrder2.getStatus());
        assertEquals(1, completedOrders.size());
        assertEquals(testOrder2, completedOrders.get(0));
        assertEquals(1, currentOrders.size());
        assertEquals(testOrder1, currentOrders.get(0));

    }

    @Test
    void testCompleteSomeOrders() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);
        testFlowerShop.addCurrentOrder(testOrder3);

        testFlowerShop.completeOrder(testOrder1);
        testFlowerShop.completeOrder(testOrder2);
        List<Order> completedOrders = testFlowerShop.getCompletedOrders();
        List<Order> currentOrders = testFlowerShop.getCurrentOrders();

        assertEquals("Complete", testOrder1.getStatus());
        assertEquals("Complete", testOrder2.getStatus());
        assertEquals(2, completedOrders.size());
        assertEquals(testOrder1, completedOrders.get(0));
        assertEquals(testOrder2, completedOrders.get(1));
        assertEquals(1, currentOrders.size());
        assertEquals(testOrder3, currentOrders.get(0));

    }


    @Test
    void testCompleteAllOrders() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);

        testFlowerShop.completeOrder(testOrder1);
        testFlowerShop.completeOrder(testOrder2);
        List<Order> completedOrders = testFlowerShop.getCompletedOrders();
        List<Order> currentOrders = testFlowerShop.getCurrentOrders();

        assertEquals("Complete", testOrder1.getStatus());
        assertEquals("Complete", testOrder2.getStatus());
        assertEquals(2, completedOrders.size());
        assertEquals(testOrder1, completedOrders.get(0));
        assertEquals(testOrder2, completedOrders.get(1));
        assertEquals(0, currentOrders.size());
    }


    @Test
    void testFindOrderExists() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);
        int orderNumber = testOrder1.getOrderNumber();
        assertEquals(testOrder1, testFlowerShop.findOrder(orderNumber));
    }

    @Test
    void testFindOrderDoesNotExists() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);
        int orderNumber = testOrder1.getOrderNumber();
        assertNull(testFlowerShop.findOrder(orderNumber + 2));
    }

    @Test
    void testGetAllCurrentOrderNumbersEmpty() {
        List<Integer> allCurrentOrderNumbers = testFlowerShop.getCurrentOrderNumbers();
        assertEquals(0, allCurrentOrderNumbers.size());
    }

    @Test
    void testGetAllCurrentOrderNumbersNotEmpty() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);
        Integer orderNumber1 = testOrder1.getOrderNumber();
        Integer orderNumber2 = testOrder2.getOrderNumber();
        List<Integer> allCurrentOrderNumbers = testFlowerShop.getCurrentOrderNumbers();
        assertEquals(2, allCurrentOrderNumbers.size());
        assertEquals(orderNumber1, allCurrentOrderNumbers.get(0));
        assertEquals(orderNumber2, allCurrentOrderNumbers.get(1));
    }

    @Test
    void testGetAllCompletedOrderNumbersEmpty() {
        List<Integer> allCurrentOrderNumbers = testFlowerShop.getCurrentOrderNumbers();
        assertEquals(0, allCurrentOrderNumbers.size());
    }

    @Test
    void testGetAllCompletedOrderNumbersNotEmpty() {
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);
        Integer orderNumber1 = testOrder1.getOrderNumber();
        Integer orderNumber2 = testOrder2.getOrderNumber();
        testFlowerShop.completeOrder(testOrder1);
        testFlowerShop.completeOrder(testOrder2);
        List<Integer> allCompletedOrderNumbers = testFlowerShop.getCompletedOrderNumbers();

        assertEquals(2, allCompletedOrderNumbers.size());
        assertEquals(orderNumber1, allCompletedOrderNumbers.get(0));
        assertEquals(orderNumber2, allCompletedOrderNumbers.get(1));
    }

    @Test
    void testOrderSummaryNoOrders(){
        List<Order> orderList = testFlowerShop.getCurrentOrders();
        List<String> summaryResults = testFlowerShop.ordersSummary(orderList);
        assertEquals(0, summaryResults.size());
    }

    @Test
    void testOrderSummaryWithOneOrder(){
        testFlowerShop.addCurrentOrder(testOrder1);
        List<Order> orderList = testFlowerShop.getCurrentOrders();
        List<String> summaryResults = testFlowerShop.ordersSummary(orderList);
        assertEquals(1, summaryResults.size());
        assertEquals(testOrder1.orderSummary(), summaryResults.get(0));
    }

    @Test
    void testOrderSummaryWithMultipleOrders(){
        testFlowerShop.addCurrentOrder(testOrder1);
        testFlowerShop.addCurrentOrder(testOrder2);
        List<Order> orderList = testFlowerShop.getCurrentOrders();
        List<String> summaryResults = testFlowerShop.ordersSummary(orderList);
        assertEquals(2, summaryResults.size());
        assertEquals(testOrder1.orderSummary(), summaryResults.get(0));
        assertEquals(testOrder2.orderSummary(), summaryResults.get(1));
    }

    @Test
    void testRecipeSummaryNoRecipes() {
        List<Recipe> allRecipes = testFlowerShop.getAllRecipes();
        List<String> recipeSummaryList = testFlowerShop.recipesSummary(allRecipes);
        assertEquals(0, recipeSummaryList.size());
    }

    @Test
    void testRecipeSummaryOneRecipes() {
        testFlowerShop.addRecipe(testRecipe1);
        List<Recipe> allRecipes = testFlowerShop.getAllRecipes();
        List<String> recipeSummaryList = testFlowerShop.recipesSummary(allRecipes);
        assertEquals(1, recipeSummaryList.size());
        assertEquals(testRecipe1.getRecipeSummary(), recipeSummaryList.get(0));
    }

    @Test
    void testRecipeSummaryMultipleRecipes() {
        testFlowerShop.addRecipe(testRecipe1);
        testFlowerShop.addRecipe(testRecipe2);
        List<Recipe> allRecipes = testFlowerShop.getAllRecipes();
        List<String> recipeSummaryList = testFlowerShop.recipesSummary(allRecipes);
        assertEquals(2, recipeSummaryList.size());
        assertEquals(testRecipe1.getRecipeSummary(), recipeSummaryList.get(0));
        assertEquals(testRecipe2.getRecipeSummary(), recipeSummaryList.get(1));
    }




    void initializeRecipes() {
        testPlantRose = new Plant("Rose", 4.95, 40);
        testPlantDaisy = new Plant("Gerbera Daisy", 3.95, 20);
        testPlantLeatherLeaf = new Plant("Leather Leaf", 1.00, 30);
        testPlantCallaLily = new Plant("Calla Lily", 8.95, 8);

        testRecipe1 = new Recipe("Summer Day Bouquet");
        testRecipe1.addPlant(testPlantRose, 6);
        testRecipe1.addPlant(testPlantLeatherLeaf, 8);

        testRecipe2 = new Recipe("Daisy Daze");
        testRecipe2.addPlant(testPlantDaisy, 12);

        testRecipe3 = new Recipe("Perfect Winter Day");
        testRecipe3.addPlant(testPlantRose, 24);
        testRecipe3.addPlant(testPlantCallaLily, 3);

        testRecipe4 = new Recipe("Nothing But Greens");
        testRecipe4.addPlant(testPlantLeatherLeaf, 25);
    }

}
