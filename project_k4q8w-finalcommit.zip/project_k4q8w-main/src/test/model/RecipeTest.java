package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class RecipeTest {

    Recipe testRecipe;
    Recipe testRecipeLowStock;

    Plant testPlantRose;
    Plant testPlantDaisy;
    Plant testPlantLeatherLeaf;
    Plant testPlantCallaLily;

    @BeforeEach
    void runBefore() {
        testPlantRose = new Plant("Rose", 4.95, 100);
        testPlantDaisy = new Plant("Gerbera Daisy", 3.95, 50);
        testPlantLeatherLeaf = new Plant("Leather Leaf", 1.00, 200);
        testPlantCallaLily = new Plant ("Calla Lily", 11.95, 2);

        testRecipe = new Recipe("Roses 'n' More");

        testRecipeLowStock = new Recipe("Calla Lily Delight");

    }

    @Test
    void testConstructor() {
        assertEquals("Roses 'n' More", testRecipe.getName());
        assertEquals(0, testRecipe.getMaterialCost());
        assertEquals(0, testRecipe.getTotalStemCount());
        assertEquals(0, testRecipe.getPlantTypeCount());

    }

    @Test
    void testAddOneFlowerToRecipe() {
        DecimalFormat df = new DecimalFormat("#####.##");
        testRecipe.addPlant(testPlantRose, 6);

        String expectedString = (testRecipe.getName() + "\nTotal cost: $" + df.format(testRecipe.calculatePrice())
                + "\n" + " - Rose: 6" + "\n");

        assertEquals(1, testRecipe.getPlantTypeCount());
        assertEquals(6, testRecipe.getTotalStemCount());
        assertEquals(expectedString, testRecipe.getRecipeSummary());

    }



    @Test
    void testAddMultipleFlowersToRecipe() {
        testRecipe.addPlant(testPlantRose, 6);
        testRecipe.addPlant(testPlantDaisy, 4);
        testRecipe.addPlant(testPlantLeatherLeaf, 12);

        List<Plant> plants = testRecipe.getPlantsNeeded();
        List<Integer> stems = testRecipe.getStemCounts();

        assertEquals(3, testRecipe.getPlantTypeCount());
        assertEquals(22, testRecipe.getTotalStemCount());
        assertEquals(testPlantRose, plants.get(0));
        assertEquals(testPlantDaisy, plants.get(1));
        assertEquals(testPlantLeatherLeaf, plants.get(2));
        assertEquals(6, stems.get(0));
        assertEquals(4, stems.get(1));
        assertEquals(12, stems.get(2));


    }

    @Test
    void testAddMultipleSameFlowersToRecipe() {
        testRecipe.addPlant(testPlantRose, 6);
        testRecipe.addPlant(testPlantRose, 10);

        List<Plant> plants = testRecipe.getPlantsNeeded();
        List<Integer> stems = testRecipe.getStemCounts();

        assertEquals(1, testRecipe.getPlantTypeCount());
        assertEquals(16, testRecipe.getTotalStemCount());
        assertEquals(testPlantRose, plants.get(0));
        assertEquals(16, stems.get(0));
    }

    @Test
    void testRemoveOnePlant() {
        testRecipe.addPlant(testPlantRose, 10);
        testRecipe.addPlant(testPlantLeatherLeaf, 8);

        testRecipe.removePlant(testPlantRose);

        List<String> expectedList = new ArrayList<>();
        expectedList.add("Leather Leaf");

        List<String> actualList = testRecipe.getPlantNamesInRecipe();

        assertEquals(1, testRecipe.getPlantTypeCount());
        assertEquals(8, testRecipe.getTotalStemCount());
        assertEquals(1, actualList.size());
        assertEquals(expectedList.get(0), actualList.get(0));

    }

    @Test
    void testRemoveMultiplePlants() {
        testRecipe.addPlant(testPlantRose, 10);
        testRecipe.addPlant(testPlantLeatherLeaf, 8);

        testRecipe.removePlant(testPlantRose);
        testRecipe.removePlant(testPlantLeatherLeaf);

        List<String> actualList = testRecipe.getPlantNamesInRecipe();

        assertEquals(0, testRecipe.getPlantTypeCount());
        assertEquals(0, testRecipe.getTotalStemCount());
        assertEquals(0, actualList.size());

    }

    @Test
    void testRemovePlantNotPresent() {
        testRecipe.addPlant(testPlantRose, 10);
        testRecipe.removePlant(testPlantLeatherLeaf);

        List<String> actualList = testRecipe.getPlantNamesInRecipe();

        assertEquals(1, testRecipe.getPlantTypeCount());
        assertEquals(10, testRecipe.getTotalStemCount());
        assertEquals(1, actualList.size());
        assertTrue(actualList.contains("Rose"));

    }

    @Test
    void testCountStemsInRecipe(){
        testRecipe.addPlant(testPlantRose, 10);
        testRecipe.addPlant(testPlantLeatherLeaf, 8);

        assertEquals(18, testRecipe.getTotalStemCount());

    }

    @Test
    public void testCalculatePriceEmptyRecipe() {
        assertEquals(0,testRecipe.calculatePrice());
    }

    @Test
    void testCalculatePriceRecipe() {
        testRecipe.addPlant(testPlantRose, 10);
        testRecipe.addPlant(testPlantLeatherLeaf, 8);
        testRecipe.setMaterialCost(10.00);

        double labour = testRecipe.getLabourCost();

        assertEquals((67.50 * labour), testRecipe.calculatePrice());

    }

    @Test
    void testCalculatePriceBlankRecipe() {
        assertEquals(0, testRecipe.calculatePrice());

    }

    @Test
    void testMakeOneRecipeAllInStock(){
        testRecipe.addPlant(testPlantRose, 10);
        testRecipe.addPlant(testPlantLeatherLeaf, 8);

        assertTrue(testRecipe.make());
        assertEquals(90, testPlantRose.getStemStock());
        assertEquals(192, testPlantLeatherLeaf.getStemStock());

    }

    @Test
    void testMakeOneRecipeNoneInStock(){
        testRecipe.addPlant(testPlantCallaLily, 10);

        assertFalse(testRecipe.make());
        assertEquals(2, testPlantCallaLily.getStemStock());

    }

    @Test
    void testMakeOneRecipeNotInStock(){
        testRecipe.addPlant(testPlantRose, 10);
        testRecipe.addPlant(testPlantCallaLily, 5);

        assertFalse(testRecipe.make());
        assertEquals(100, testPlantRose.getStemStock());
        assertEquals(2, testPlantCallaLily.getStemStock());

    }

    @Test
    void testMakeRecipeMultipleTimesSuccess(){
        testRecipe.addPlant(testPlantRose, 5);
        testRecipe.addPlant(testPlantLeatherLeaf, 10);

        assertTrue(testRecipe.make());
        assertTrue(testRecipe.make());

        assertEquals(90, testPlantRose.getStemStock());
        assertEquals(180, testPlantLeatherLeaf.getStemStock());

    }

    @Test
    void testMakeRecipeMultipleTimesFailAtZeroStock(){
        testRecipe.addPlant(testPlantRose, 5);
        testRecipe.addPlant(testPlantCallaLily, 1);

        assertTrue(testRecipe.make());
        assertTrue(testRecipe.make());
        assertFalse(testRecipe.make());

        assertEquals(90, testPlantRose.getStemStock());
        assertEquals(0, testPlantCallaLily.getStemStock());

    }

    @Test
    void testMakeRecipeMultipleTimesFailAtNotEnoughStock(){
        testRecipe.addPlant(testPlantRose, 20);
        testRecipe.addPlant(testPlantDaisy, 20);

        assertTrue(testRecipe.make());
        assertTrue(testRecipe.make());
        assertFalse(testRecipe.make());

        assertEquals(60, testPlantRose.getStemStock());
        assertEquals(10, testPlantDaisy.getStemStock());

    }

    @Test
    void testCheckEnoughStocksAllTrue(){
        testRecipe.addPlant(testPlantRose, 20);
        testRecipe.addPlant(testPlantLeatherLeaf, 12);
        testRecipe.addPlant(testPlantDaisy, 3);

        assertTrue(testRecipe.checkEnoughStocksForRecipe());

    }

    @Test
    void testCheckEnoughStocksOneExactlyTrue(){
        testRecipe.addPlant(testPlantRose, 20);
        testRecipe.addPlant(testPlantLeatherLeaf, 12);
        testRecipe.addPlant(testPlantCallaLily, 2);

        assertTrue(testRecipe.checkEnoughStocksForRecipe());

    }

    @Test
    void testCheckEnoughStocksOneExactlyFalse(){
        testRecipe.addPlant(testPlantRose, 20);
        testRecipe.addPlant(testPlantLeatherLeaf, 12);
        testRecipe.addPlant(testPlantCallaLily, 3);

        assertFalse(testRecipe.checkEnoughStocksForRecipe());

    }

    @Test
    void testCheckEnoughStocksOneFalse(){
        testRecipe.addPlant(testPlantRose, 24);
        testRecipe.addPlant(testPlantLeatherLeaf, 12);
        testRecipe.addPlant(testPlantCallaLily, 5);

        assertFalse(testRecipe.checkEnoughStocksForRecipe());

    }

    @Test
    void testCheckEnoughStocksAllFalse(){
        testRecipe.addPlant(testPlantRose, 200);
        testRecipe.addPlant(testPlantLeatherLeaf, 1200);
        testRecipe.addPlant(testPlantCallaLily, 5);

        assertFalse(testRecipe.checkEnoughStocksForRecipe());

    }

    @Test
    void testGetFlowersInBlankRecipe(){
        DecimalFormat df = new DecimalFormat("#####.##");
        String expectedSummary = ("Roses 'n' More" + "\nTotal cost: $" + df.format(testRecipe.calculatePrice())
                + "\n" + "\n");
        assertEquals(expectedSummary, testRecipe.getRecipeSummary());
    }

    @Test
    void testGetFlowersInNonBlankRecipe(){
        testRecipe.addPlant(testPlantRose, 20);
        testRecipe.addPlant(testPlantLeatherLeaf, 12);

        String expectedString = (testRecipe.getName() + "\nTotal cost: $" + testRecipe.calculatePrice()
                + "\n" + " - Rose: 20 - Leather Leaf: 12" + "\n");

        assertEquals(2, testRecipe.getPlantTypeCount());
        assertEquals(32, testRecipe.getTotalStemCount());
        assertEquals(expectedString, testRecipe.getRecipeSummary());
    }

    @Test
    void testGetStemsNeededForPlantInRecipe() {
        testRecipe.addPlant(testPlantRose, 20);
        testRecipe.addPlant(testPlantLeatherLeaf, 12);

        assertEquals(20, testRecipe.getStemsNeededForPlant(testPlantRose));

    }

    @Test
    void testGetPlantFromNameDoesNotExist(){
        testRecipe.addPlant(testPlantRose, 5);
        testRecipe.addPlant(testPlantDaisy, 10);

        assertNull(testRecipe.findPlant("Lily"));
    }

    @Test
    void testGetPlantFromNameDoesExist(){
        testRecipe.addPlant(testPlantRose, 5);
        testRecipe.addPlant(testPlantDaisy, 10);

        assertEquals(testPlantRose, testRecipe.findPlant("Rose"));
    }

    @Test
    void testGetPlantNamesEmptyRecipe() {
        List<String> plantNamesResult = testRecipe.getPlantNamesInRecipe();
        assertEquals(0, plantNamesResult.size());
    }

    @Test
    void testGetPlantNamesNonEmptyRecipe() {
        testRecipe.addPlant(testPlantRose, 5);
        testRecipe.addPlant(testPlantDaisy, 2);
        List<String> plantNamesResult = testRecipe.getPlantNamesInRecipe();
        assertEquals(2, plantNamesResult.size());
        assertEquals("Rose", plantNamesResult.get(0));
        assertEquals("Gerbera Daisy", plantNamesResult.get(1));
    }

    @Test
    void testChangeNameOnce(){
        testRecipe.setName("Test");
        assertEquals("Test", testRecipe.getName());
    }

    @Test
    void testChangeNameMultiple(){
        testRecipe.setName("Test");
        testRecipe.setName("Happy Flowers");
        assertEquals("Happy Flowers", testRecipe.getName());
    }






}
