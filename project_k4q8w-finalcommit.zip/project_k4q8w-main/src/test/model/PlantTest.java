package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlantTest {

    Plant testPlantInStock;
    Plant testPlantNotInStock;

    @BeforeEach
    void runBefore() {
        testPlantInStock = new Plant("Rose", 4.95, 40);
        testPlantNotInStock = new Plant("Hyacinth", 6.95, 0);

    }

    @Test
    void testConstructor() {
        assertEquals("Rose", testPlantInStock.getName());
        assertEquals(4.95, testPlantInStock.getPerStemPrice());
        assertEquals(40, testPlantInStock.getStemStock());
    }

    @Test
    void testChangePriceNewPrice() {
        testPlantInStock.changePrice(5.95);
        assertEquals(5.95, testPlantInStock.getPerStemPrice());

    }

    @Test
    void testChangePriceSamePrice() {
        testPlantInStock.changePrice(4.95);
        assertEquals(4.95, testPlantInStock.getPerStemPrice());

    }

    @Test
    void testChangePriceMultipleTimes() {
        testPlantInStock.changePrice(5.95);
        testPlantInStock.changePrice(3.95);
        assertEquals(3.95, testPlantInStock.getPerStemPrice());

    }

    @Test
    void testAddStockOnce() {
        testPlantInStock.addStock(10);
        assertEquals(50, testPlantInStock.getStemStock());
    }

    @Test
    void testAddStockMultipleTimes() {
        testPlantInStock.addStock(10);
        testPlantInStock.addStock(30);
        assertEquals(80, testPlantInStock.getStemStock());
    }

    @Test
    void testSellStemsEnoughInStock() {
        assertTrue(testPlantInStock.sellStems(8));
        assertEquals(32, testPlantInStock.getStemStock());

    }

    @Test
    void testSellStemsExactlyEnoughInStock() {
        assertTrue(testPlantInStock.sellStems(40));
        assertEquals(0, testPlantInStock.getStemStock());

    }

    @Test
    void testSellStemsZeroStemsInStock() {
        assertFalse(testPlantNotInStock.sellStems(10));
        assertEquals(0, testPlantNotInStock.getStemStock());

    }

    @Test
    void testSellStemsOneMoreThanStock() {
        assertFalse(testPlantInStock.sellStems(41));
        assertEquals(40, testPlantInStock.getStemStock());

    }

    @Test
    void testSellStemsNotEnoughStemsInStock() {
        assertFalse(testPlantInStock.sellStems(100));
        assertEquals(40, testPlantInStock.getStemStock());

    }

    @Test
    void testSellMultipleTimesEnoughStock() {
        assertTrue(testPlantInStock.sellStems(10));
        assertTrue(testPlantInStock.sellStems(5));

        assertEquals(25, testPlantInStock.getStemStock());

    }

    @Test
    void testSellMultipleRunOutOfStock() {
        assertTrue(testPlantInStock.sellStems(10));
        assertFalse(testPlantInStock.sellStems(50));

        assertEquals(30, testPlantInStock.getStemStock());


    }

    @Test
    void testPlantSummary() {
        assertEquals("Rose: 40 - $4.95 ea.", testPlantInStock.getPlantSummary());
    }









}