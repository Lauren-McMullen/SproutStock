package persistence;

import model.FlowerShop;
import model.Order;
import model.Plant;
import model.Recipe;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class JsonReaderTest extends JsonTest {


    @Test
    void testReaderNonExistentFile() {
        JsonReader reader = new JsonReader("./data/fakeFile.json");
        try {
            FlowerShop fs = reader.read();
            fail("IOException expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testReaderEmptyFlowerShop() {
        JsonReader reader = new JsonReader("./data/testReaderEmptyFlowerShop.json");

        try {
            FlowerShop fs = reader.read();
            assertEquals("Empty Flower Shop", fs.getName());

            List<Recipe> recipes = fs.getAllRecipes();
            assertEquals(0, recipes.size());

            List<Order> currOrders = fs.getCurrentOrders();
            assertEquals(0, currOrders.size());

            List<Order> completedOrders = fs.getCompletedOrders();
            assertEquals(0, completedOrders.size());

            List<Plant> inventory = fs.getInventory();
            assertEquals(0, inventory.size());

            //pass

        } catch (IOException e) {
            fail ("File not read correctly");
        }
    }

    @Test
    void testSampleFlowerShopName() {
        JsonReader reader = new JsonReader("./data/testReaderSampleFlowerShop.json");
        try {
            FlowerShop fs = reader.read();
            assertEquals("Sample Flower Shop", fs.getName());
            //pass
        } catch (IOException e) {
            fail ("File not read correctly");
        }
    }

    @Test
    void testSampleFlowerShopPlantInventory() {
        JsonReader reader = new JsonReader("./data/testReaderSampleFlowerShop.json");

        try {
            FlowerShop fs = reader.read();

            List<Plant> inventory = fs.getInventory();
            checkPlant("Rose", 4.50, 50, inventory.get(0));
            checkPlant("Lily", 9.95, 25, inventory.get(1));
            checkPlant("Leather Leaf", 1.00, 100, inventory.get(2));

            //pass
        } catch (IOException e) {
            fail ("File not read correctly");
        }

    }

    @Test
    void testSampleFlowerShopRecipes() {
        JsonReader reader = new JsonReader("./data/testReaderSampleFlowerShop.json");

            try {
                FlowerShop fs = reader.read();
                List<Recipe> recipes = fs.getAllRecipes();

                //SummerDay
                List<Integer> summerDayStems = recipes.get(0).getStemCounts();
                checkRecipe("Summer Day", 8.00, recipes.get(0));
                checkPlant("Rose", 4.50, 50, recipes.get(0).findPlant("Rose"));
                checkPlant("Lily", 9.95, 25, recipes.get(0).findPlant("Lily"));
                assertEquals(6, summerDayStems.get(0));
                assertEquals(8, summerDayStems.get(1));

                //Roses Galore
                List<Integer> RosesGaloreStems = recipes.get(1).getStemCounts();
                checkRecipe("Roses Galore", 12.50, recipes.get(1));
                checkPlant("Rose", 4.50, 50, recipes.get(1).findPlant("Rose"));
                checkPlant("Leather Leaf", 1.00, 100, recipes.get(1).findPlant("Leather Leaf"));
                assertEquals(24, RosesGaloreStems.get(0));
                assertEquals(10, RosesGaloreStems.get(1));

                //Nothing But Greens
                List<Integer> greensStems = recipes.get(2).getStemCounts();
                checkRecipe("Nothing but Greens", 5.00, recipes.get(2));
                checkPlant("Leather Leaf", 1.00, 100, recipes.get(1).findPlant("Leather Leaf"));
                assertEquals(20, greensStems.get(0));


                //pass
            } catch (IOException e) {
                fail ("File not read correctly");
            }
    }

    @Test
    void testSampleFlowerShopOrders() {
        JsonReader reader = new JsonReader("./data/testReaderSampleFlowerShop.json");

        try {
            FlowerShop fs = reader.read();

            List<Order> currentOrders = fs.getCurrentOrders();
            List<Order> completedOrders = fs.getCompletedOrders();

            //Order 1
            checkOrder(1, "Not Complete", currentOrders.get(0));
            List<Recipe> orderOneRecipes = currentOrders.get(0).getOrderRecipes();

                //Nothing But Greens
            List<Integer> orderOneGreensStems = orderOneRecipes.get(0).getStemCounts();
            checkRecipe("Nothing but Greens", 5.00, orderOneRecipes.get(0));
            checkPlant("Leather Leaf", 1.00, 100,
                    orderOneRecipes.get(1).findPlant("Leather Leaf"));
            assertEquals(20, orderOneGreensStems.get(0));
                //Roses Galore
            List<Integer> RosesGaloreStems = orderOneRecipes.get(1).getStemCounts();
            checkRecipe("Roses Galore", 12.50, orderOneRecipes.get(1));
            checkPlant("Rose", 4.50, 50, orderOneRecipes.get(1).findPlant("Rose"));
            checkPlant("Leather Leaf", 1.00, 100,
                    orderOneRecipes.get(1).findPlant("Leather Leaf"));
            assertEquals(24, RosesGaloreStems.get(0));
            assertEquals(10, RosesGaloreStems.get(1));
            
            //Order 2
            checkOrder(2, "Not Complete", currentOrders.get(1));
            List<Recipe> orderTwoRecipes = currentOrders.get(1).getOrderRecipes();

                //Nothing But Greens
            List<Integer> orderTwoGreensStems = orderTwoRecipes.get(0).getStemCounts();
            checkRecipe("Nothing but Greens", 5.00, orderTwoRecipes.get(0));
            checkPlant("Leather Leaf", 1.00, 100,
                    orderTwoRecipes.get(0).findPlant("Leather Leaf"));
            assertEquals(20, orderTwoGreensStems.get(0));

            //Order 3
            checkOrder(3, "Complete", completedOrders.get(0));
            List<Recipe> orderThreeRecipes = completedOrders.get(0).getOrderRecipes();

                //Nothing But Greens
            List<Integer> orderThreeGreensStems = orderThreeRecipes.get(0).getStemCounts();
            checkRecipe("Nothing but Greens", 5.00, orderThreeRecipes.get(0));
            checkPlant("Leather Leaf", 1.00, 100,
                    orderThreeRecipes.get(0).findPlant("Leather Leaf"));
            assertEquals(20, orderThreeGreensStems.get(0));

            //pass

        } catch (IOException e) {
            fail ("File not read correctly");
        }
    }

}
