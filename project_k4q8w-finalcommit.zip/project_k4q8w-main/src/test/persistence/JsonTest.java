package persistence;

import model.Order;
import model.Plant;
import model.Recipe;


import static org.junit.jupiter.api.Assertions.*;

// CREDIT: the format of the persistence test package were learned from and modelled after the
//         CPSC 210 EDx example JsonSerializationDemo: https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo

public class JsonTest {

    // Checks that all Plant fields match the given parameters from JSONObject
    protected void checkPlant(String name, double price, int stems, Plant plant) {
        assertEquals(name, plant.getName());
        assertEquals(price, plant.getPerStemPrice());
        assertEquals(stems, plant.getStemStock());
    }

    // Checks that all Recipe fields match the given parameters from JSONObject
    protected void checkRecipe(String name, double materials, Recipe recipe) {
        assertEquals(name, recipe.getName());
        assertEquals(materials, recipe.getMaterialCost());
    }

    protected void checkOrder(int orderNum, String status, Order order) {
        assertEquals(orderNum, order.getOrderNumber());
        assertEquals(status, order.getStatus());
    }





}
