package persistence;

import model.FlowerShop;
import model.Order;
import model.Plant;
import model.Recipe;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class JsonWriterTest extends JsonTest {

    @Test
    void testWriterInvalidFile() {

        try {
            FlowerShop fs = new FlowerShop("Sample Flower Shop");
            JsonWriter writer = new JsonWriter("./data/\0myfakefilename.json");
            writer.open();
            fail("IOException expected");
        } catch (IOException e) {
            //pass
        }
    }

    @Test
    void testWriterEmptyFlowerShop() {
        try {
            FlowerShop fs = new FlowerShop("Empty Flower Shop");
            JsonWriter writer = new JsonWriter("./data/testWriterEmptyFlowerShop.json");
            writer.open();
            writer.write(fs);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterEmptyFlowerShop.json");
            fs = reader.read();
            assertEquals("Empty Flower Shop", fs.getName());
            assertEquals(0, fs.getInventory().size());
            assertEquals(0, fs.getAllRecipes().size());
            assertEquals(0, fs.getCurrentOrders().size());
            assertEquals(0, fs.getCompletedOrders().size());

        } catch (IOException e) {
            fail("IOException not expected but was thrown");
        }
    }

    @Test
    void testWriterSampleFlowerShop() {
        try {
            FlowerShop fs = flowerShopSetUp();
            JsonWriter writer = new JsonWriter("./data/testWriterSampleFlowerShop.json");
            writer.open();
            writer.write(fs);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterSampleFlowerShop.json");
            fs = reader.read();

            assertEquals("Sample Flower Shop", fs.getName());
            testSampleFlowerShopInventory(fs);
            testSampleFlowerShopRecipes(fs);
            testSampleFlowerShopOrders(fs);
        } catch (IOException e){
            fail("IOException not expected but was thrown");
        }
    }

    private void testSampleFlowerShopInventory(FlowerShop fs) {
        List<Plant> inventory = fs.getInventory();
        checkPlant("Rose", 4.50, 25, inventory.get(0));
        checkPlant("Lily", 9.95, 10, inventory.get(1));
    }

    private void testSampleFlowerShopRecipes(FlowerShop fs) {
        List<Recipe> recipes = fs.getAllRecipes();
        Recipe testRecipe = recipes.get(0);
        checkRecipe("testRecipe", 5.00, testRecipe);
        checkPlant("Rose", 4.50, 25, testRecipe.findPlant("Rose"));
        checkPlant("Lily", 9.95, 10, testRecipe.findPlant("Lily"));
    }

    private void testSampleFlowerShopOrders(FlowerShop fs) {
        List<Order> currentOrders = fs.getCurrentOrders();
        List<Order> completedOrders = fs.getCompletedOrders();
        Order currentOrder = currentOrders.get(0);
        Order completedOrder = completedOrders.get(0);


        checkOrder(139,"Complete", completedOrder);
        List<Recipe> orderOneRecipes = completedOrder.getOrderRecipes();
        Recipe orderOneRecipe = orderOneRecipes.get(0);
        checkRecipe("testRecipe", 5.00, orderOneRecipe);
        checkPlant("Rose", 4.50, 25, orderOneRecipe.findPlant("Rose"));
        checkPlant("Lily", 9.95, 10, orderOneRecipe.findPlant("Lily"));

        checkOrder(140,"Not Complete", currentOrder);
        List<Recipe> orderTwoRecipes = completedOrder.getOrderRecipes();
        Recipe orderTwoRecipe = orderTwoRecipes.get(0);
        checkRecipe("testRecipe", 5.00, orderTwoRecipe);
        checkPlant("Rose", 4.50, 25, orderTwoRecipe.findPlant("Rose"));
        checkPlant("Lily", 9.95, 10, orderTwoRecipe.findPlant("Lily"));
    }

    private FlowerShop flowerShopSetUp() {
        FlowerShop fs = new FlowerShop("Sample Flower Shop");

        Plant plantRose = new Plant("Rose", 4.50, 25);
        Plant plantLily = new Plant("Lily", 9.95, 10);

        Recipe recipeOne = new Recipe("testRecipe");
        recipeOne.addPlant(plantRose, 10);
        recipeOne.addPlant(plantLily, 3);
        recipeOne.setMaterialCost(5.00);
        List<Recipe> recipeList = new ArrayList<>();
        recipeList.add(recipeOne);

        Order orderComplete = new Order(recipeList);
        Order orderCurrent = new Order(recipeList);

        fs.addInventory(plantRose);
        fs.addInventory(plantLily);
        fs.addRecipe(recipeOne);
        fs.addCurrentOrder(orderCurrent);
        fs.addCompletedOrder(orderComplete);

        return fs;
    }

}
